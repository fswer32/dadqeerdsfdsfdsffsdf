/**

 * The types are explicity for learning purpose
 */

/**

 * The types are explicity for learning purpose
 */
import type { PoolOptions } from 'mysql2/promise';
import { MySQL } from './db.js';
const access: PoolOptions = {
  host: 'mysql-1eacb932-kdwz-a5a3.c.aivencloud.com',
  user: 'avnadmin',
  port:14966,
  password: 'AVNS_YkfY36wVj2UbEWXsa1F',
  database: 'defaultdb',
  multipleStatements: true,
  connectionLimit: 3,  
  idleTimeout: 60000, // idle connections timeout, in milliseconds, the default value 60000
  
};
const tid: PoolOptions = {
  host: 'mysql-d8e4fe8-kdwz-81e6.g.aivencloud.com',
  user: 'avnadmin',
  port:27417,
  password: 'AVNS_cUS2H5NtnXD-XkN7MFN',
  database: 'defaultdb',
  multipleStatements: true,
  connectionLimit: 3,  
  idleTimeout: 60000, // idle connections timeout, in milliseconds, the default value 60000
  
};
export const mysql = new MySQL(access);
export const mysql2 = new MySQL(tid);
//  /** Inserting some users */
//   const [inserted] = await mysql.executeResult(
//     'INSERT INTO `users`(`name`) VALUES(?), (?), (?), (?);',
//     ['Josh', 'John', 'Marie', 'Gween']
//   );

//   //console.log('Inserted:', inserted.affectedRows);

//   /** Getting users */
//   const [users] = await mysql.queryRows(
//     'SELECT * FROM `users` ORDER BY `name` ASC;'
//   );
//   await mysql.connection.end();
/** For `INSERT`, `UPDATE`, etc. */ 
//多条插入 
export async function queryResults(sql:string,params:any) {
    // 在发生错误时触发
    try {
      const [inserted] = await mysql.queryResults(sql,[params]);
     // await mysql.connection.end(); // 添加这行来关闭连接
      return inserted;
    } catch (err) {
      if (err instanceof Error) {
        //console.log('execute error:', err);
      }
      return 'infodata';
    }
     
}
//单条插入更新数据
export async function queryResult(sql:string,params:any) {
  // 在发生错误时触发
  try {
    const [inserted] = await mysql.queryResult(sql,params);
   // await mysql.connection.end(); // 添加这行来关闭连接
    return inserted;
  } catch (err) {
    if (err instanceof Error) {
      //console.log('execute error:', err);
    }
    return 'infodata';
  }
   
}


 /** For `SELECT` and `SHOW` with `rowAsArray` as `true` */
export async function queryRowsAsArray(params:any) {
  try {
    const [users] = await mysql.queryRowsAsArray(params );     
  //  await mysql.connection.end(); // 添加这行来关闭连接    
    let resultArr = []
     for(let item of users){
    resultArr.push(item)

    }
    return resultArr;  
  } catch (err) {  
    if (err instanceof Error) {
      //console.log('query error:', err);
    }
      return 'infodata';   
  }
}
/** For `SELECT` and `SHOW` */ 
//单条查询或者多条查询
export async function queryRows(params:any) {
  try {
    const [users] = await mysql.queryRows(params );    
   // await mysql.connection.end(); // 添加这行来关闭连接     
    //let resultArr = []
    //console.log(users)
    //  for(let item of users){
    // resultArr.push(item)

    // }
    return users;  
  } catch (err) {  
    if (err instanceof Error) {
      //console.log('query error:', err);
    }
      return 'infodata';   
  }
}

/** For `SELECT` and `SHOW` */ 
//单条查询或者多条查询
export async function queryRowsBing(sql:string ,params:any) {
  try {
    const [users] = await mysql.queryRows(sql,params );    
    //await mysql.connection.end(); // 添加这行来关闭连接     
    // let resultArr = []
    //  for(let item of users){
    // resultArr.push(item)

    // }
    return users;  
  } catch (err) {  
    if (err instanceof Error) {
      //console.log('query error:', err);
    }
      return 'infodata';   
  }
}




export async function queryRowsTid(params:any) {

  try {
    const [users] = await mysql2.queryRows(params );    
   // await mysql2.connection.end(); // 添加这行来关闭连接     
    //let resultArr = []
    //console.log(users)
    //  for(let item of users){
    // resultArr.push(item)

    // }
    return users;  
  } catch (err) {  
    if (err instanceof Error) {
      //console.log('query error:', err);
    }
      return 'infodata';   
  }
}

/** For `SELECT` and `SHOW` */ 
//单条查询或者多条查询
export async function queryRowsBingTid(sql:string ,params:any) {
  try {
    const [users] = await mysql2.queryRows(sql,params );    
   // await mysql2.connection.end(); // 添加这行来关闭连接     
    // let resultArr = []
    //  for(let item of users){
    // resultArr.push(item)

    // }
    return users;  
  } catch (err) {  
    if (err instanceof Error) {
      //console.log('query error:', err);
    }
      return 'infodata';   
  }
}
/** Output

 *      * Inserted: 4

 * -----------

 * id:   4

 * name: Gween

 * -----------

 * id:   2

 * name: John

 * -----------

 * id:   1

 * name: Josh

 * -----------

 * id:   3

 * name: Marie
 */