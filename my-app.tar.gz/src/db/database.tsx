import { queryResults, queryRowsAsArray, queryRows, queryResult, queryRowsBing, queryRowsTid, queryRowsBingTid } from "./dbmysql.js"
// 1. 首先在文件顶部添加TiDB连接配置



////多条插入 queryResults
//单条插入更新数据queryResult
//单条查询或者多条查询queryRows
/**
 * 
 *  let inf: any
    inf = await queryRows(sql)
    if (inf == false) {
        return false;
    }

     const extsq ='INSERT INTO ce (name) VALUES ?';
     const values = [
          ['value1_1212']
            ];
      let infd:any=await queryResults(extsq,values)
    
    const extsq = 'UPDATE  blog_archives SET newblog = ?,categories = ? ,tags = ?,archives = ?,postscount = ?,tagscount = ?,categorycount = ?  WHERE id=1';
    const values = [blog_posts1, blog_category1, blog_tags1, archives1, postscount1, tagscount1, categorycount1];
    let infd: any = await queryResult(extsq, values)
 * @returns 
     let posta1 = { "type": "categories", "page": 1, "size": size, "categories": id }
 */
export async function savesql(params1: any) {
  let params = JSON.parse(params1)
  let type = params['type']
  let reinfo: any = 'infodata'
  switch (type) {
    case 'query':
      let sql = params['sql']
      reinfo = await squery(sql);

      break;
    case 'query1':
      reinfo = await squery1(params);

      break;
    case 'index':
      reinfo = await sindex(params);
      break;
    case 'tags':
      reinfo = await stags(params);
      break;
    case 'categories':
      reinfo = await scategories(params);
      break;
    case 'archives':
      reinfo = await sarchives(params);
      break;
    case 'tagspost':
      reinfo = await stagspost(params);
      break;
    case 'posts':
      reinfo = await sposts(params);
      break;
    case 'saveEdit':
      reinfo = await saveEdit(params);
      break;
    case 'saveAddNew':
      reinfo = await saveAddNew(params);
      break;
    case 'deleted':
      reinfo = await sdel(params);
      break;
    default:

  }
  return reinfo;


}
async function saveAddNew(params: any) {
  try {
    let title = params['title']
    let description = params['description']
    let content = params['content']
    let time = params['time']
    let last_update_time = params['last_update_time']
    let cover_image_url = params['cover_image_url']
    let del = params['del'] || 0  // 获取del参数，默认值为0

    let category1: string = params['category'].toUpperCase();
    let category2 = category1.replaceAll('，', ',')
    let category = category2.split(/[,，]+/);
    let tag1: string = params['tag'].toUpperCase();
    let tag2 = tag1.replaceAll('，', ',')
    let tag = tag2.split(/[,，]+/);
    let albumId = params['albumId'] || '';
    // ... existing code ...
    const extsq = `INSERT INTO blog_posts  (title,description,content,category,tag,time,last_update_time,cover_image_url,del,album_id) VALUES ? ;`;

    const values = [title, description, content, category1, tag1, time, last_update_time, cover_image_url, del, albumId]  // 继续添加更多的值 ;
    let infd: any = await queryResult(extsq, [[values]])
    // ... existing code ...
    ////console.log(infd)
    if (infd === 'infodata') {
      return 'infodata'
    }
    let blog_id = infd['insertId']
    if (blog_id) {
      let post_cate: any[] = []
      let sql = `SELECT category_id  FROM blog_category where category_name = ? limit 1; `

      let sqlcateins = `INSERT INTO blog_category  (category_name,catenum) VALUES ? ;`
      let sqlcateup = `UPDATE  blog_category SET catenum = catenum+1 where category_id = ? ;`

      let sqltag = `SELECT id  FROM blog_tags where name = ? limit 1; `

      let sqltagtagins = `INSERT INTO blog_tags  (name,cate_num) VALUES ? ; `
      let tagup = `UPDATE  blog_tags SET cate_num = cate_num+1 where id = ? ;`
      let cateinsall = `INSERT INTO post_cate  (blogid,cateid) VALUES ? ;`

      let posttagall = `INSERT INTO post_tag  (post_id,tag) VALUES ? ;`

      let delcte = `DELETE FROM post_cate  WHERE blogid =? ;`

      let deltag = `DELETE FROM post_tag  WHERE post_id =? ;`
      let inf: any
      let category_id: string
      for (let i = 0; i < category.length; i++) {
        if (category[i] != "" && category[i] != null && category[i] != undefined) {

          inf = await queryRowsBing(sql, [category[i]])
          if (inf.length != 0) {
            category_id = inf[0]['category_id']
            inf = await queryResult(sqlcateup, [category_id])
            post_cate.push([blog_id, category_id]);

          } else {
            inf = await queryResults(sqlcateins, [[category[i], 1]])
            category_id = inf['insertId']
            post_cate.push([blog_id, category_id]);
          }

        }
      }
      await queryResult(delcte, [blog_id])
      let sds1 = await queryResults(cateinsall, post_cate)
      ////console.log(sds1)
      let paotag: any[] = []
      for (let i = 0; i < tag.length; i++) {
        if (tag[i] != "" && tag[i] != null && tag[i] != undefined) {

          inf = await queryRowsBing(sqltag, [tag[i]])
          if (inf.length != 0) {
            category_id = inf[0]['id']
            inf = await queryResult(tagup, [category_id])
            paotag.push([blog_id, category_id]);

          } else {
            inf = await queryResults(sqltagtagins, [[tag[i], 1]])
            category_id = inf['insertId']
            paotag.push([blog_id, category_id]);
          }

        }
      }
      ////console.log(paotag)
      await queryResult(deltag, [blog_id])
      let sds = await queryResults(posttagall, paotag)
      ////console.log(sds)


    }
    await cacheobj()
    return infd

  } catch (error) {
   // console.error('saveAddNew函数执行错误:', error)
    return 'infodata'
  }

}

async function saveEdit(params: any) {
  let blog_id = params['blog_id']
  let title = params['title']
  let description = params['description']
  let content = params['content']
  let time = params['time']
  let last_update_time = params['last_update_time']
  let cover_image_url = params['cover_image_url']

  let category1: string = params['category'].toUpperCase();
  let category2 = category1.replaceAll('，', ',')
  let category = category2.split(/[,，]+/);
  let tag1: string = params['tag'].toUpperCase();
  let tag2 = tag1.replaceAll('，', ',')
  let tag = tag2.split(/[,，]+/);
  let albumId = params['albumId'] || '';
  const extsq = `UPDATE blog_posts SET title = ? , description = ? , content = ? , category = ? , tag = ?, time = ? , last_update_time = ? ,cover_image_url = ? ,album_id = ? WHERE blog_id = ?;`;


  const values = [title, description, content, category1, tag1, time, last_update_time, cover_image_url, albumId, blog_id]  // 继续添加更多的值 ;
  let infd: any = await queryResult(extsq, values)
  // ////console.log(infd)
  let changedRows = infd['changedRows']
  // ////console.log(changedRows)
  if (changedRows == 1) {
    let post_cate: any[] = []
    let sql = `SELECT category_id  FROM blog_category where category_name = ? limit 1; `

    let sqlcateins = `INSERT INTO blog_category  (category_name,catenum) VALUES ? ;`
    let sqlcateup = `UPDATE  blog_category SET catenum = catenum+1 where category_id = ? ;`

    let sqltag = `SELECT id  FROM blog_tags where name = ? limit 1; `

    let sqltagtagins = `INSERT INTO blog_tags  (name,cate_num) VALUES ? ; `
    let tagup = `UPDATE  blog_tags SET cate_num = cate_num+1 where id = ? ;`
    let cateinsall = `INSERT INTO post_cate  (blogid,cateid) VALUES ? ;`

    let posttagall = `INSERT INTO post_tag  (post_id,tag) VALUES ? ;`

    let delcte = `DELETE FROM post_cate  WHERE blogid =? ;`

    let deltag = `DELETE FROM post_tag  WHERE post_id =? ;`
    let inf: any
    let category_id: string
    for (let i = 0; i < category.length; i++) {
      if (category[i] != "" && category[i] != null && category[i] != undefined) {

        inf = await queryRowsBing(sql, [category[i]])
        if (inf.length != 0) {
          category_id = inf[0]['category_id']
          inf = await queryResult(sqlcateup, [category_id])
          post_cate.push([blog_id, category_id]);

        } else {
          inf = await queryResults(sqlcateins, [[category[i], 1]])
          category_id = inf['insertId']
          post_cate.push([blog_id, category_id]);
        }

      }
    }
    await queryResult(delcte, [blog_id])
    let sds1 = await queryResults(cateinsall, post_cate)
    // ////console.log(sds1)
    let paotag: any[] = []
    for (let i = 0; i < tag.length; i++) {
      if (tag[i] != "" && tag[i] != null && tag[i] != undefined) {

        inf = await queryRowsBing(sqltag, [tag[i]])
        if (inf.length != 0) {
          category_id = inf[0]['id']
          inf = await queryResult(tagup, [category_id])
          paotag.push([blog_id, category_id]);

        } else {
          inf = await queryResults(sqltagtagins, [[tag[i], 1]])
          category_id = inf['insertId']
          paotag.push([blog_id, category_id]);
        }

      }
    }
    //////console.log(paotag)
    await queryResult(deltag, [blog_id])
    let sds = await queryResults(posttagall, paotag)
    // ////console.log(sds)


  }
  await cacheobj()
  return infd
}


async function sposts(params: any) {
  let categories = ''

  if (params.hasOwnProperty("categories")) {
    categories = params["categories"];
  }
  if (typeof categories === "undefined" || categories === null || categories === '') {
    return "infodata";
  }

  let sql = `SELECT blog_id  FROM blog_posts  ORDER BY  blog_id desc limit 1;

 SELECT blog_id,title,content,tag,category,DATE_FORMAT (blog_posts.time ,'%Y-%m-%d %H:%i:%s') AS time ,DATE_FORMAT (blog_posts.last_update_time ,'%Y-%m-%d %H:%i:%s') AS last_update_time ,album_id FROM blog_posts WHERE blog_id = ? ;
  SELECT * FROM blog_archives  WHERE id =1;
  
  (SELECT 'previous' AS type, blog_id, title, description, cover_image_url 
   FROM blog_posts 
   WHERE blog_id < ? 
   ORDER BY blog_id DESC LIMIT 1)
  UNION ALL
  (SELECT 'next' AS type, blog_id, title, description, cover_image_url 
   FROM blog_posts 
   WHERE blog_id > ? 
   ORDER BY blog_id ASC LIMIT 1);
   `;
  let infocount: any = await queryRowsBing(sql, [categories, categories, categories]);

  if (infocount == "infodata") {
    return {
      'allchae': '',
      'allchaeCO': infocount[0]['blog_id'],
      'psotinfo': '',
      'fno': '1',
      'endid': infocount[3],
      'prevNext': infocount[4]  // 添加上下篇文章数据
    }
  }

  if (await isEmpty(infocount[1])) {
    return {
      'allchae': '',
      'allchaeCO': infocount[0]['blog_id'],
      'psotinfo': '',
      'fno': '1',
      'endid': infocount[3],
      'prevNext': infocount[4]  // 添加上下篇文章数据
    }
  }

  let redata = {
    'allchae': infocount[2],
    'allchaeCO': infocount[0][0]['blog_id'],
    'psotinfo': infocount[1],
    'fno': '0',
    'prevNext': infocount[3]  // 添加上下篇文章数据
  };
  return redata;
}



async function stagspost(params: any) {

  let page = 1;
  if (params.hasOwnProperty('page')) {
    page = await intsrt(params["page"]);
  }
  let size = 40;
  if (params.hasOwnProperty("size")) {
    size = await intsrt(params["size"]);
  }
  if (page < 2) {
    page = 1;
  }


  let categories = ''

  if (params.hasOwnProperty("categories")) {
    categories = params["categories"];
  }
  if (typeof categories === "undefined" || categories === null || categories === '') {
    return "infodata";
  }

  let slimit = (page - 1) * size;
  let sql = `SELECT COUNT(*) AS cn FROM blog_tags  join  

	post_tag   on blog_tags.id=post_tag.tag 

	join blog_posts on  post_tag.post_id = blog_posts.blog_id

	where blog_tags.name = ? AND blog_tags.state=1 ;

 SELECT blog_posts.description,blog_posts.cover_image_url,blog_posts.blog_id,blog_posts.title,DATE_FORMAT (blog_posts.time,'%Y-%m-%d %H:%i:%s') AS time FROM blog_tags  join  

	post_tag   on blog_tags.id=post_tag.tag 
	join blog_posts on  post_tag.post_id = blog_posts.blog_id

	where blog_tags.name =? AND blog_tags.state=1 

	ORDER BY  blog_posts.blog_id desc limit  ?, ?;
  SELECT * FROM blog_archives  WHERE id =1;
   `;
  let infocount = await queryRowsBing(sql, [categories, categories, slimit, size]);

  if (infocount == "infodata") {
    return infocount;
  }

  let redata = { 'allchaeCO': infocount[0], 'psotinfo': infocount[1], 'allchae': infocount[2] };
  ////console.log('redata')
  ////console.log(redata)
  return redata;


  // $redata=['allchae'=>$allchae,'allchaeCO'=>$infocount,'psotinfo'=>$psotinfo];
  // return $redata;
}
async function sarchives(params: any) {

  let page = 1;
  if (params.hasOwnProperty('page')) {
    page = await intsrt(params["page"]);
  }
  let size = 40;
  if (params.hasOwnProperty("size")) {
    size = await intsrt(params["size"]);
  }
  if (page < 2) {
    page = 1;
  }


  let categories = ''

  if (params.hasOwnProperty("categories")) {
    categories = params["categories"];
  }
  if (typeof categories === "undefined" || categories === null || categories === '') {
    return "infodata";
  }

  let slimit = (page - 1) * size;
  let sql = `SELECT COUNT(*) AS cn from blog_posts  WHERE DATE_FORMAT(time,'%Y-%m') =?  ;

 SELECT blog_posts.description,blog_posts.cover_image_url,blog_posts.blog_id,blog_posts.title,DATE_FORMAT (blog_posts.time ,'%Y-%m-%d %H:%i:%s') AS time   from blog_posts  WHERE DATE_FORMAT(time,'%Y-%m') =?  order by blog_id desc limit  ?, ?;
  SELECT * FROM blog_archives  WHERE id =1;
   `;
  let infocount = await queryRowsBing(sql, [categories, categories, slimit, size]);

  if (infocount == "infodata") {
    return infocount;
  }

  let redata = { 'allchaeCO': infocount[0], 'psotinfo': infocount[1], 'allchae': infocount[2] };
  ////console.log('redata')
  ////console.log(redata)
  return redata;


  // $redata=['allchae'=>$allchae,'allchaeCO'=>$infocount,'psotinfo'=>$psotinfo];
  // return $redata;
}


async function scategories(params: any) {

  let page = 1;
  if (params.hasOwnProperty('page')) {
    page = await intsrt(params["page"]);
  }
  let size = 40;
  if (params.hasOwnProperty("size")) {
    size = await intsrt(params["size"]);
  }
  if (page < 2) {
    page = 1;
  }


  let categories = ''

  if (params.hasOwnProperty("categories")) {
    categories = params["categories"];
  }
  if (typeof categories === "undefined" || categories === null || categories === '') {
    return "infodata";
  }

  let slimit = (page - 1) * size;
  let sql = `SELECT COUNT(*) AS cn FROM blog_category  join   

	post_cate   on blog_category.category_id=post_cate.cateid  

	join blog_posts on  post_cate.blogid = blog_posts.blog_id  

	where  blog_category.category_name =? AND blog_category.tagdel=0 ;

    SELECT blog_posts.description,blog_posts.cover_image_url,blog_posts.blog_id,blog_posts.title, DATE_FORMAT (blog_posts.time ,'%Y-%m-%d %H:%i:%s') AS time  FROM blog_category  join  

	post_cate   on blog_category.category_id=post_cate.cateid  

	join blog_posts on  post_cate.blogid = blog_posts.blog_id 

	where blog_category.category_name =? AND blog_category.tagdel=0 
  
  
  ORDER BY  blog_posts.blog_id desc LIMIT ?, ?;
    SELECT * FROM blog_archives  WHERE id =1;
     `;
  let infocount = await queryRowsBing(sql, [categories, categories, slimit, size]);

  if (infocount == "infodata") {
    return infocount;
  }

  let redata = { 'allchaeCO': infocount[0], 'psotinfo': infocount[1], 'allchae': infocount[2] };
  ////console.log('redata')
  ////console.log(redata)
  return redata;


  // $redata=['allchae'=>$allchae,'allchaeCO'=>$infocount,'psotinfo'=>$psotinfo];
  // return $redata;
}


async function stags(params: any) {

  let page = 1;
  if (params.hasOwnProperty('page')) {
    page = await intsrt(params["page"]);
  }
  let size = 40;
  if (params.hasOwnProperty("size")) {
    size = await intsrt(params["size"]);
  }
  if (page < 2) {
    page = 1;
  }
  let slimit = (page - 1) * size;
  let sql = `SELECT COUNT(*) AS cn FROM blog_tags where state=1;
    SELECT name from blog_tags where  state=1  ORDER BY  cate_num desc  limit  ?, ?;
    SELECT * FROM blog_archives  WHERE id =1;
     `;
  let infocount = await queryRowsBing(sql, [slimit, size]);

  if (infocount == "infodata") {
    return infocount;
  }

  let redata = { 'allchaeCO': infocount[0], 'psotinfo': infocount[1], 'allchae': infocount[2] };
  ////console.log(redata)
  return redata;


  // $redata=['allchae'=>$allchae,'allchaeCO'=>$infocount,'psotinfo'=>$psotinfo];
  // return $redata;
}





async function sindex(params: any) {

  let page = 1;
  if (params.hasOwnProperty('page')) {
    page = await intsrt(params["page"]);
  }
  let size = 40;
  if (params.hasOwnProperty("size")) {
    size = await intsrt(params["size"]);
  }
  if (page < 2) {
    page = 1;
  }
  let slimit = (page - 1) * size;
  let sql = `SELECT COUNT(blog_id) AS cn FROM blog_posts ;
      SELECT blog_posts.cover_image_url,blog_id, title,description,DATE_FORMAT (time,'%Y-%m-%d %H:%i:%s') AS time FROM blog_posts  ORDER BY  blog_id desc limit ?, ?;
      SELECT * FROM blog_archives  WHERE id =1;

       `;
  let infocount = await queryRowsBing(sql, [slimit, size]);

  if (infocount == "infodata") {
    return infocount;
  }

  let redata = { 'allchaeCO': infocount[0], 'psotinfo': infocount[1], 'allchae': infocount[2] };
  //console.log(redata)
  return redata;


  // $redata=['allchae'=>$allchae,'allchaeCO'=>$infocount,'psotinfo'=>$psotinfo];
  // return $redata;
}
async function sdel(params: any) {

  let page = 1;
  if (params.hasOwnProperty('page')) {
    page = await intsrt(params["page"]);
  }
  let size = 40;
  if (params.hasOwnProperty("size")) {
    size = await intsrt(params["size"]);
  }
  if (page < 2) {
    page = 1;
  }
  let slimit = (page - 1) * size;
  let sql = `SELECT COUNT(blog_id) AS cn FROM blog_posts where del=1 ;
      SELECT blog_posts.cover_image_url,blog_id, title,description,DATE_FORMAT (time,'%Y-%m-%d %H:%i:%s') AS time FROM blog_posts where del =1  ORDER BY  blog_id desc limit ?, ?;
      SELECT * FROM blog_archives  WHERE id =1;

       `;
  let infocount = await queryRowsBing(sql, [slimit, size]);

  if (infocount == "infodata") {
    return infocount;
  }

  let redata = { 'allchaeCO': infocount[0], 'psotinfo': infocount[1], 'allchae': infocount[2] };
  //console.log(redata)
  return redata;


  // $redata=['allchae'=>$allchae,'allchaeCO'=>$infocount,'psotinfo'=>$psotinfo];
  // return $redata;
}






// 2. 修改query和query1方法
async function squery1(params: any) {
  let sql = params['sql']
  let bin = params['bin']

  const isTgFile = /(FROM|INTO|UPDATE)\s+tg_file/i.test(sql);

  if (isTgFile) {


    return await queryRowsBingTid(sql, bin);
  } else {
    return await queryRowsBing(sql, bin);
  }

}

async function squery(sql: string) {

  const isTgFile = /(FROM|INTO|UPDATE)\s+tg_file/i.test(sql);

  if (isTgFile) {

    return await queryRowsTid(sql);
  } else {
    return await queryRows(sql);
  }

}

//更新数据
async function cacheobj() {
  let sql = `SELECT blog_id ,title ,DATE_FORMAT (time,'%Y-%m-%d %H:%i:%s') AS time  FROM blog_posts  ORDER BY  blog_id desc  limit 5`;
  let inf: any
  inf = await queryRows(sql)
  if (inf == false) {
    return false;
  }
  let blog_posts1 = JSON.stringify(inf);

  sql = 'SELECT category_id ,category_name,catenum   FROM blog_category WHERE tagdel = 0 ORDER BY  catenum desc  '
  inf = await queryRows(sql)
  if (inf == false) {
    return false;
  }
  let blog_category1 = JSON.stringify(inf);
  sql = 'SELECT id ,name   FROM blog_tags where state =1  ORDER BY  cate_num desc limit 10'
  inf = await queryRows(sql)
  if (inf == false) {
    return false;
  }
  let blog_tags1 = JSON.stringify(inf);

  sql = `SELECT DATE_FORMAT(  time,'%Y-%m') as y,count(*) AS count from blog_posts  GROUP BY DATE_FORMAT(  time,'%Y-%m');`
  inf = await queryRows(sql)
  if (inf == false) {
    return false;
  }
  let archives1 = JSON.stringify(inf);

  sql = `SELECT COUNT(*) AS postscount   FROM blog_posts `
  inf = await queryRows(sql)
  if (inf == false) {
    return false;
  }
  let postscount1 = JSON.stringify(inf[0]['postscount']);

  sql = `SELECT COUNT(*) AS categorycount   FROM blog_category WHERE tagdel = 0`
  inf = await queryRows(sql)
  if (inf == false) {
    return false;
  }
  let categorycount1 = JSON.stringify(inf[0]['categorycount']);


  sql = `SELECT COUNT(*) AS tagscount   FROM blog_tags where state =1`
  inf = await queryRows(sql)
  if (inf == false) {
    return false;
  }
  let tagscount1 = JSON.stringify(inf[0]['tagscount']);

  const extsq = 'UPDATE  blog_archives SET newblog = ?,categories = ? ,tags = ?,archives = ?,postscount = ?,tagscount = ?,categorycount = ?  WHERE id=1';
  const values = [blog_posts1, blog_category1, blog_tags1, archives1, postscount1, tagscount1, categorycount1];
  let infd: any = await queryResult(extsq, values)

  return infd;

}
async function intsrt(str: string) {
  let int = parseInt(str);
  const b = Math.pow(2, 31);
  if (String(int) == 'NaN') {
    int = 0;
  } else if (int < -b) {
    int = -b;
  } else if (int > b - 1) {
    int = b - 1;
  }
  return int;

}

async function isEmpty(obj: any) {
  return Object.keys(obj).length === 0;
}