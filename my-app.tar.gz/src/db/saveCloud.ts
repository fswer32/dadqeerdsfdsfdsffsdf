import { CouchbaseClientAPI } from "./CouchbaseClientAPI.js";
import { generatecryptoUUIDv4 } from "../uuid.js";

// 初始化 Couchbase 客户端https://cb.spliz9pnfmo1uqt.cloud.couchbase.com.kdwz.qzz.io/query/service
//https://cb.spliz9pnfmo1uqt.cloud.couchbase.com.kdwz.qzz.io/query/service
//  https://edge-coubase-cyshu.98272.qzz.io/Honosql/couchbase/s   edgeone  coubase 数据
//cb.spliz9pnfmo1uqt.cloud.couchbase.com
const couchbaseClient = new CouchbaseClientAPI(
  process.env.COUCHBASE_MAIN_URL || "https://",
  process.env.COUCHBASE_USERNAME || "",
  process.env.COUCHBASE_PASSWORD || "",
  process.env.COUCHBASE_BUCKET || "o",
  process.env.COUCHBASE_SCOPE || "db"
);
const couchbaseClientFile = new CouchbaseClientAPI(
  process.env.COUCHBASE_FILE_URL || "https://",
  process.env.COUCHBASE_USERNAME || "",
  process.env.COUCHBASE_PASSWORD || "",
  process.env.COUCHBASE_BUCKET || "0",
  process.env.COUCHBASE_SCOPE || "db"
);

// 定义集合名称
const COLLECTIONS = {
  BLOG_POSTS: "blog_posts",
  BLOG_CATEGORY: "blog_category",
  BLOG_TAGS: "blog_tags",
  POST_CATE: "post_cate",
  POST_TAG: "post_tag",
  BLOG_ARCHIVES: "blog_archives",
  COUNTER: "counter",
  TG_FILE: "tg_file",
  BLOG_ARCHIVE_MONTHS: "blog_archive_months",

};

// 工具函数：将字符串转换为整数
async function intsrt(str: string): Promise<number> {
  const int = parseInt(str);
  const b = Math.pow(2, 31);
  if (isNaN(int)) {
    return 0;
  } else if (int < -b) {
    return -b;
  } else if (int > b - 1) {
    return b - 1;
  }
  return int;
}

// 工具函数：检查对象是否为空
async function isEmpty(obj: any): Promise<boolean> {
  return Object.keys(obj).length === 0;
}

// 获取自增 blog_id
// async function getNextBlogId(): Promise<number> {
//   const counterKey = "counter::blog_id";
//   try {
//     const result = await couchbaseClient.query<{ value: number }>(
//       `UPDATE \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.COUNTER}\` 
//        USE KEYS $1 
//        SET \`value\` = IFMISSINGORNULL(\`value\`, 0) + 1 
//        RETURNING \`value\``,
//       [counterKey]
//     );
//     return result[0]?.value ?? 1;
//   } catch (error) {
//     //console.error("获取 blog_id 失败:", error);
//     throw error;
//   }
// }
async function getNextBlogId(): Promise<number> {
  try {
    const result = await couchbaseClient.query<{ max_blog_id: number }>(
      `SELECT MAX(blog_id) as max_blog_id FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_POSTS}\``
    );
    return (result[0]?.max_blog_id ?? 0) + 1;
  } catch (error) {
    //console.error("获取 blog_id 失败:", error);
    return 1; // 如果查询失败，返回默认值1
  }
}


// 获取自增 category_id
async function getNextCategoryId(): Promise<number> {
  const counterKey = "counter::category_id";
  try {
    const result = await couchbaseClient.query<{ value: number }>(
      `UPDATE \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.COUNTER}\` 
       USE KEYS $1 
       SET \`value\` = IFMISSINGORNULL(\`value\`, 0) + 1 
       RETURNING \`value\``,
      [counterKey]
    );
    return result[0]?.value ?? 1;
  } catch (error) {
    //console.error("获取 category_id 失败:", error);
    throw error;
  }
}

// 获取自增 tag_id
async function getNextTagId(): Promise<number> {
  const counterKey = "counter::tag_id";
  try {
    const result = await couchbaseClient.query<{ value: number }>(
      `UPDATE \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.COUNTER}\` 
       USE KEYS $1 
       SET \`value\` = IFMISSINGORNULL(\`value\`, 0) + 1 
       RETURNING \`value\``,
      [counterKey]
    );
    return result[0]?.value ?? 1;
  } catch (error) {
    //console.error("获取 tag_id 失败:", error);
    throw error;
  }
}

// 获取自增 post_cate id
async function getNextPostCateId(): Promise<number> {
  const counterKey = "counter::post_cate_id";
  try {
    const result = await couchbaseClient.query<{ value: number }>(
      `UPDATE \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.COUNTER}\` 
       USE KEYS $1 
       SET \`value\` = IFMISSINGORNULL(\`value\`, 0) + 1 
       RETURNING \`value\``,
      [counterKey]
    );
    return result[0]?.value ?? 1;
  } catch (error) {
    //console.error("获取 post_cate_id 失败:", error);
    throw error;
  }
}

// 获取自增 post_tag id
async function getNextPostTagId(): Promise<number> {
  const counterKey = "counter::post_tag_id";
  try {
    const result = await couchbaseClient.query<{ value: number }>(
      `UPDATE \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.COUNTER}\` 
       USE KEYS $1 
       SET \`value\` = IFMISSINGORNULL(\`value\`, 0) + 1 
       RETURNING \`value\``,
      [counterKey]
    );
    return result[0]?.value ?? 1;
  } catch (error) {
    //console.error("获取 post_tag_id 失败:", error);
    throw error;
  }
}
// 获取自增 tg_file_id
async function getNextTgFileId(): Promise<number> {
  const counterKey = "counter::tg_file_id";
  try {
    const result = await couchbaseClientFile.query<{ value: number }>(
      `UPDATE \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.COUNTER}\` 
       USE KEYS $1 
       SET \`value\` = IFMISSINGORNULL(\`value\`, 0) + 1 
       RETURNING \`value\``,
      [counterKey]
    );
    if (!result[0]?.value) throw new Error("Failed to increment tg_file_id");
    return result[0].value;
  } catch (error) {
    //console.error("获取 tg_file_id 失败:", error);
    throw error;
  }
}
// 处理分类关联
async function processCategories(categories: string[], blogId: string): Promise<void> {
  const associations: [string, number, number][] = []; // [blogId, cateId, id]

  for (const category of categories) {
    if (category) {
      // 查询分类是否存在
      const sqlSelect = `
        SELECT category_id FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_CATEGORY}\` 
        WHERE category_name = $1 LIMIT 1
      `;
      const result = await couchbaseClient.query<{ category_id: number }>(sqlSelect, [category]);

      let categoryId: number;
      if (result.length > 0) {
        // 分类存在，更新 catenum
        categoryId = result[0].category_id;
        await couchbaseClient.query(
          `UPDATE \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_CATEGORY}\` 
           SET catenum = catenum + 1 WHERE category_id = $1`,
          [categoryId]
        );
      } else {
        // 分类不存在，插入新分类
        categoryId = await getNextCategoryId();
        const doc = {
          category_id: categoryId,
          category_name: category,
          catenum: 1,
          tagdel: 0,
        };
        await couchbaseClient.table(COLLECTIONS.BLOG_CATEGORY).insert(`category_id::${categoryId}`, doc);
      }

      // 生成 post_cate 的自增 id
      const postCateId = await getNextPostCateId();
      associations.push([blogId, categoryId, postCateId]);
    }
  }

  // 删除旧的分类关联
  if (associations.length > 0) {
    await couchbaseClient.query(
      `DELETE FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.POST_CATE}\` 
       WHERE blogid = $1`,
      [blogId]
    );

    // 插入新的分类关联
    for (const [blogId, cateId, postCateId] of associations) {
      const key = `post_cate::${blogId}::${cateId}`;
      const value = { id: postCateId, blogid: parseInt(blogId), cateid: cateId };
      await couchbaseClient.table(COLLECTIONS.POST_CATE).insert(key, value);
    }
  }
}

// 处理标签关联
async function processTags(tags: string[], blogId: string): Promise<void> {
  const associations: [string, number, number][] = []; // [blogId, tagId, id]

  for (const tag of tags) {
    if (tag) {
      // 查询标签是否存在
      const sqlSelect = `
        SELECT id FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_TAGS}\` 
        WHERE name = $1 LIMIT 1
      `;
      const result = await couchbaseClient.query<{ id: number }>(sqlSelect, [tag]);

      let tagId: number;
      if (result.length > 0) {
        // 标签存在，更新 cate_num
        tagId = result[0].id;
        await couchbaseClient.query(
          `UPDATE \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_TAGS}\` 
           SET cate_num = cate_num + 1 WHERE id = $1`,
          [tagId]
        );
      } else {
        // 标签不存在，插入新标签
        tagId = await getNextTagId();
        const doc = {
          id: tagId,
          name: tag,
          cate_num: 1,
          state: 1,
        };
        await couchbaseClient.table(COLLECTIONS.BLOG_TAGS).insert(`id::${tagId}`, doc);
      }

      // 生成 post_tag 的自增 id
      const postTagId = await getNextPostTagId();
      associations.push([blogId, tagId, postTagId]);
    }
  }

  // 删除旧的标签关联
  if (associations.length > 0) {
    await couchbaseClient.query(
      `DELETE FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.POST_TAG}\` 
       WHERE post_id = $1`,
      [blogId]
    );

    // 插入新的标签关联
    for (const [blogId, tagId, postTagId] of associations) {
      const key = `post_tag::${blogId}::${tagId}`;
      const value = { id: postTagId, post_id: parseInt(blogId), tag: tagId };
      await couchbaseClient.table(COLLECTIONS.POST_TAG).insert(key, value);
    }
  }
}

// 保存新博客文章
async function saveAddNew(params: any): Promise<number> {
  try {
    const {
      blog_id: inputBlogId,
      title,
      description,
      content,
      time,
      last_update_time,
      cover_image_url,
      category: categoryRaw,
      tag: tagRaw,
      albumId = "",
      del = 0,
    } = params;
    // 1. 确定最终的 blog_id
    let finalBlogId: number;

    // 如果前端传了有效的 blog_id，则使用它；否则生成新的
    if (inputBlogId && inputBlogId !== "" && !isNaN(Number(inputBlogId))) {
      finalBlogId = await intsrt(inputBlogId);
    } else {
      finalBlogId = await getNextBlogId();
    }
    // 处理分类和标签
    const category1 = categoryRaw.toUpperCase().replace(/，/g, ",");
    const categories = category1.split(/[,，]+/).filter(Boolean);
    const tag1 = tagRaw.toUpperCase().replace(/，/g, ",");
    const tags = tag1.split(/[,，]+/).filter(Boolean);

    // 获取自增 blogId
    const blogKey = `post::${finalBlogId}`;

    // 插入博客文章
    const blogDoc = {
      blog_id: finalBlogId,
      title,
      description,
      content,
      category: category1,
      tag: tag1,
      time,
      last_update_time,
      cover_image_url,
      del,
      album_id: albumId,
    };
    // 提取年月
    let yearMonth = '';
    if (params.time && typeof params.time === 'string' && params.time.match(/^\d{4}-\d{1,2}-\d{1,2}\s/)) {
      yearMonth = params.time.substring(0, 7); // 提取 "2025-05"
      yearMonth = yearMonth.replace(/-(\d)$/, '-0$1'); // 规范化 "2025-5" -> "2025-05"
    }

    // 更新 blog_archive_months 的 count
    if (yearMonth) {
      const monthDocId = `month::${yearMonth}`;
      const monthDoc: any = await couchbaseClient.table(COLLECTIONS.BLOG_ARCHIVE_MONTHS)
        .get(monthDocId)
        .catch(() => null);
      const currentCount = monthDoc?.count ?? 0; // 安全访问 count，默认为 0

      await couchbaseClient.table(COLLECTIONS.BLOG_ARCHIVE_MONTHS).upsert(monthDocId, {
        id: monthDocId,
        year_month: yearMonth,
        count: currentCount + 1
      });
    }




    const insertResult = await couchbaseClient.table(COLLECTIONS.BLOG_POSTS).insert(blogKey, blogDoc);
    const blog_id = parseInt(insertResult.insertId.split("::")[1]);

    // 处理分类
    await processCategories(categories, blog_id.toString());

    // 处理标签
    await processTags(tags, blog_id.toString());

    // 更新缓存
    await cacheobj();
    return 1;
  } catch (error) {
    //console.error("保存新文章失败:", error);
    throw error;
  }
}

// 编辑现有博客文章
async function saveEdit(params: any): Promise<number> {
  try {
    const {
      blog_id: blogIdStr,
      title,
      description,
      content,
      time,
      last_update_time,
      cover_image_url,
      category: categoryRaw,
      tag: tagRaw,
      albumId = "",
      del = 0,
    } = params;

    // 处理分类和标签
    const category1 = categoryRaw.toUpperCase().replace(/，/g, ",");
    const categories = category1.split(/[,，]+/).filter(Boolean);
    const tag1 = tagRaw.toUpperCase().replace(/，/g, ",");
    const tags = tag1.split(/[,，]+/).filter(Boolean);
    // 将blog_id转换为整数
    const blog_id = await intsrt(blogIdStr);  // 添加这行转换
    // 更新博客文章
    const blogKey = `post::${blog_id}`;
    const blogDoc = {
      blog_id,
      title,
      description,
      content,
      category: category1,
      tag: tag1,
      time,
      last_update_time,
      cover_image_url,
      del,
      album_id: albumId,
    };
    const updateResult = await couchbaseClient.table(COLLECTIONS.BLOG_POSTS).replace(blogKey, blogDoc);

    if (updateResult.changedRows === 1) {
      // 处理分类
      await processCategories(categories, blog_id.toString());

      // 处理标签
      await processTags(tags, blog_id.toString());

      // 更新缓存
      await cacheobj();
    }

    return 1;
  } catch (error) {
    //console.error("编辑文章失败:", error);
    throw error;
  }
}

// 主入口函数
export async function savesqlcub(params1: any): Promise<any> {
  let params: any;
  try {
    params = JSON.parse(params1);
  } catch (error) {
    return "infodata";
  }
  try {
    const type = params["type"];
    let reinfo: any = "infodata";

    switch (type) {
      case "query":
        reinfo = await squery(params["sql"]);
        break;
      case "query_y":
        reinfo = await squeryy(params["sql"]);
        break;
      case "query1":
        reinfo = await squery1(params);
        break;
      case "query1_y":
        reinfo = await squery1y(params);
        break;

      case "index":
        reinfo = await sindex(params);
        break;
      case "tags":
        reinfo = await stags(params);
        break;
      case "categories":
        reinfo = await scategories(params);
        break;
      case "archives":
        reinfo = await sarchives(params);
        break;
      case "tagspost":
        reinfo = await stagspost(params);
        break;
      case "posts":
        reinfo = await sposts(params);
        break;
      case "saveEdit":
        reinfo = await saveEdit(params);
        break;
      case "saveAddNew":
        reinfo = await saveAddNew(params);
        break;
      case "deleted":
        reinfo = await sdel(params);
        break;
      case "queryBlogPosts":
        reinfo = await queryBlogPosts();
        break; case "addTgFile":
        reinfo = await addTgFile(params);
        break;
      case "deleteTgFile":
        reinfo = await deleteTgFile(params.fullId);
        break;
      case "updateTgFile":
        reinfo = await updateTgFile(params.fullId, params.updates);
        break;
      case "queryTgFile":
        reinfo = await queryTgFile(params);
        break;
      default:
        reinfo = "infodata";
    }
    return reinfo;
  } catch (error) {
    //console.error("savesql 执行失败:", error);
    throw error;
  }
}

// 以下函数保持不变，仅列出以确保完整性
async function sposts(params: any): Promise<any> {
  let categories = "";
  if (params.hasOwnProperty("categories")) {
    categories = params["categories"];
  }
  if (!categories) {
    return "infodata";
  }

  const sqls = [
    `SELECT blog_id FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_POSTS}\`  
     WHERE blog_id >0 
     ORDER BY blog_id DESC LIMIT 1`,
    `SELECT blog_id, title, content, tag, category, 
          time,
            last_update_time, 
            album_id 
     FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_POSTS}\` 
     WHERE blog_id = $1`,
    `SELECT ${COLLECTIONS.BLOG_ARCHIVES}.* FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_ARCHIVES}\` 
     WHERE id = 'archives::1'`,
    `(SELECT 'previous' AS type, blog_id, title, description, cover_image_url 
      FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_POSTS}\` 
      WHERE blog_id < $1 
      ORDER BY blog_id DESC LIMIT 1)
     UNION
     (SELECT 'next' AS type, blog_id, title, description, cover_image_url 
      FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_POSTS}\` 
      WHERE blog_id > $1 
      ORDER BY blog_id ASC LIMIT 1)`,
  ];

  const infocount = await couchbaseClient.query<any>(sqls, [categories]);

  if (!Array.isArray(infocount) || infocount.length < 4) {
    return {
      allchae: "",
      allchaeCO: "",
      psotinfo: "",
      fno: "1",
      prevNext: infocount[3] ?? [],
    };
  }

  if (await isEmpty(infocount[1])) {
    return {
      allchae: "",
      allchaeCO: "",
      psotinfo: "",
      fno: "1",
      prevNext: infocount[3] ?? [],
    };
  }

  return {
    allchae: infocount[2],
    allchaeCO: infocount[0][0]?.blog_id ?? "",
    psotinfo: infocount[1],
    fno: "0",
    prevNext: infocount[3],
  };
}

async function stagspost(params: any): Promise<any> {
  let page = 1;
  if (params.hasOwnProperty("page")) {
    page = await intsrt(params["page"]);
  }
  let size = 40;
  if (params.hasOwnProperty("size")) {
    size = await intsrt(params["size"]);
  }
  if (page < 2) {
    page = 1;
  }

  let categories = "";
  if (params.hasOwnProperty("categories")) {
    categories = params["categories"];
  }
  if (!categories) {
    return "infodata";
  }

  const slimit = (page - 1) * size;
  const sqls = [
    `SELECT COUNT(*) AS cn 
     FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_TAGS}\` AS bt
     JOIN \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.POST_TAG}\` AS pt ON bt.id = pt.tag
     JOIN \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_POSTS}\` AS bp ON pt.post_id = bp.blog_id
     WHERE bt.name = $1 AND bt.state = 1`,
    `SELECT bp.description, bp.cover_image_url, bp.blog_id, bp.title, 
            bp.time  
     FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_TAGS}\` AS bt
     JOIN \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.POST_TAG}\` AS pt ON bt.id = pt.tag
     JOIN \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_POSTS}\` AS bp ON pt.post_id = bp.blog_id
     WHERE bt.name = $1  AND bp.blog_id > 0 
     ORDER BY bp.blog_id DESC LIMIT $2 OFFSET $3`,
    `SELECT ${COLLECTIONS.BLOG_ARCHIVES}.* FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_ARCHIVES}\` 
     WHERE id = 'archives::1'`,
  ];

  const infocount = await couchbaseClient.query<any>(sqls, [categories, slimit, size]);

  if (!Array.isArray(infocount) || infocount.length < 3) {
    return "infodata";
  }

  return {
    allchaeCO: infocount[0],
    psotinfo: infocount[1],
    allchae: infocount[2],
  };
}

async function sarchives(params: any): Promise<any> {
  let page = 1;
  if (params.hasOwnProperty("page")) {
    page = await intsrt(params["page"]);
  }
  let size = 40;
  if (params.hasOwnProperty("size")) {
    size = await intsrt(params["size"]);
  }
  if (page < 2) {
    page = 1;
  }

  let categories = "";
  if (params.hasOwnProperty("categories")) {
    categories = params["categories"];
  }
  if (!categories) {
    return "infodata";
  }

  const slimit = (page - 1) * size;
  const sqls = [
    `SELECT COUNT(*) AS cn 
     FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_POSTS}\` 
     WHERE time LIKE '$1%'`,
    `SELECT description, cover_image_url, blog_id, title, 
            time 
     FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_POSTS}\` 
     WHERE time LIKE '$1%'  AND blog_id > 0 
     ORDER BY blog_id DESC LIMIT $2 OFFSET $3`,
    `SELECT ${COLLECTIONS.BLOG_ARCHIVES}.* FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_ARCHIVES}\` 
     WHERE id = 'archives::1'`,
  ];

  const infocount = await couchbaseClient.query<any>(sqls, [categories, slimit, size]);

  if (!Array.isArray(infocount) || infocount.length < 3) {
    return "infodata";
  }

  return {
    allchaeCO: infocount[0],
    psotinfo: infocount[1],
    allchae: infocount[2],
  };
}

async function scategories(params: any): Promise<any> {
  let page = 1;
  if (params.hasOwnProperty("page")) {
    page = await intsrt(params["page"]);
  }
  let size = 40;
  if (params.hasOwnProperty("size")) {
    size = await intsrt(params["size"]);
  }
  if (page < 2) {
    page = 1;
  }

  let categories = "";
  if (params.hasOwnProperty("categories")) {
    categories = params["categories"];
  }
  if (!categories) {
    return "infodata";
  }

  const slimit = (page - 1) * size;
  const sqls = [
    `SELECT COUNT(*) AS cn 
     FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_CATEGORY}\` AS bc
     JOIN \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.POST_CATE}\` AS pc ON bc.category_id = pc.cateid
     JOIN \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_POSTS}\` AS bp ON pc.blogid = bp.blog_id
     WHERE bc.category_name = $1 AND bc.tagdel = 0`,
    `SELECT bp.description, bp.cover_image_url, bp.blog_id, bp.title, 
            bp.time  
     FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_CATEGORY}\` AS bc
     JOIN \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.POST_CATE}\` AS pc ON bc.category_id = pc.cateid
     JOIN \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_POSTS}\` AS bp ON pc.blogid = bp.blog_id
     WHERE bc.category_name = $1   AND bp.blog_id > 0 
     ORDER BY bp.blog_id DESC LIMIT $2 OFFSET $3`,
    `SELECT ${COLLECTIONS.BLOG_ARCHIVES}.* FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_ARCHIVES}\` 
     WHERE id = 'archives::1'`,
  ];

  const infocount = await couchbaseClient.query<any>(sqls, [categories, slimit, size]);

  if (!Array.isArray(infocount) || infocount.length < 3) {
    return "infodata";
  }

  return {
    allchaeCO: infocount[0],
    psotinfo: infocount[1],
    allchae: infocount[2],
  };
}

async function stags(params: any): Promise<any> {
  let page = 1;
  if (params.hasOwnProperty("page")) {
    page = await intsrt(params["page"]);
  }
  let size = 40;
  if (params.hasOwnProperty("size")) {
    size = await intsrt(params["size"]);
  }
  if (page < 2) {
    page = 1;
  }

  const slimit = (page - 1) * size;
  const sqls = [
    `SELECT COUNT(*) AS cn 
     FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_TAGS}\` 
     WHERE state = 1`,
    `SELECT name 
     FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_TAGS}\` 
     WHERE state = 1  AND cate_num >=0 
     ORDER BY cate_num DESC LIMIT $1 OFFSET $2`,
    `SELECT ${COLLECTIONS.BLOG_ARCHIVES}.* FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_ARCHIVES}\` 
     WHERE id = 'archives::1'`,
  ];

  const infocount = await couchbaseClient.query<any>(sqls, [size, slimit]);

  if (!Array.isArray(infocount) || infocount.length < 3) {
    return "infodata";
  }

  return {
    allchaeCO: infocount[0],
    psotinfo: infocount[1],
    allchae: infocount[2],
  };
}

async function sindex(params: any): Promise<any> {
  let page = 1;
  if (params.hasOwnProperty("page")) {
    page = await intsrt(params["page"]);
  }
  let size = 40;
  if (params.hasOwnProperty("size")) {
    size = await intsrt(params["size"]);
  }
  if (page < 2) {
    page = 1;
  }

  const slimit = (page - 1) * size;
  const sqls = [
    `SELECT COUNT(blog_id) AS cn   FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_POSTS}\``,
    `SELECT cover_image_url, blog_id, title, description,  time   FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_POSTS}\`  WHERE blog_id > 0    ORDER BY blog_id DESC LIMIT $1 OFFSET $2`,
    `SELECT ${COLLECTIONS.BLOG_ARCHIVES}.* FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_ARCHIVES}\`     WHERE id = 'archives::1'`,
  ];
  //console.log("sindex:", sqls)

  const infocount = await couchbaseClient.query<any>(sqls, [size, slimit]);

  if (!Array.isArray(infocount) || infocount.length < 3) {
    return "infodata";
  }

  return {
    allchaeCO: infocount[0],
    psotinfo: infocount[1],
    allchae: infocount[2],
  };
}

async function sdel(params: any): Promise<any> {
  let page = 1;
  if (params.hasOwnProperty("page")) {
    page = await intsrt(params["page"]);
  }
  let size = 40;
  if (params.hasOwnProperty("size")) {
    size = await intsrt(params["size"]);
  }
  if (page < 2) {
    page = 1;
  }

  const slimit = (page - 1) * size;
  const sqls = [
    `SELECT COUNT(blog_id) AS cn 
     FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_POSTS}\` 
     WHERE del = 1`,
    `SELECT cover_image_url, blog_id, title, description, 
             time 
     FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_POSTS}\` 
     WHERE del = 1 
     ORDER BY blog_id DESC LIMIT $1 OFFSET $2`,
    `SELECT ${COLLECTIONS.BLOG_ARCHIVES}.* FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_ARCHIVES}\` 
     WHERE id = 'archives::1'`,
  ];

  const infocount = await couchbaseClient.query<any>(sqls, [size, slimit]);

  if (!Array.isArray(infocount) || infocount.length < 3) {
    return "infodata";
  }

  return {
    allchaeCO: infocount[0],
    psotinfo: infocount[1],
    allchae: infocount[2],
  };
}

// async function squery(sql: any): Promise<any> {
//   try {
//     return await couchbaseClient.query(sql, []);
//   } catch (error) {
//     //console.error("查询失败:", error);
//     throw error;
//   }
// }

// async function squery1(params: any): Promise<any> {
//   const sql = params["sql"];
//   const bin = params["bin"] || [];
//   try {
//     return await couchbaseClient.query(sql, bin);
//   } catch (error) {
//     //console.error("查询失败:", error);
//     throw error;
//   }
// }

// 修改现有的squery函数
async function squery(sql: any): Promise<any> {
  try {
    return await smartQuery(sql, []);
  } catch (error) {
    //console.error("查询失败:", error);
    throw error;
  }
}

// 修改现有的squery1函数
async function squery1(params: any): Promise<any> {
  const sql = params["sql"];
  const bin = params["bin"] || [];
  try {
    return await smartQuery(sql, bin);
  } catch (error) {
    //console.error("查询失败:", error);
    throw error;
  }
}

async function squeryy(sql: any): Promise<any> {
  try {
    // 检测SQL语句中的表名，确定使用哪个Couchbase客户端
    let client = couchbaseClient; // 默认使用主客户端

    // 检查是否包含tg_file表，如果是则使用文件客户端
    // 使用正则表达式精确检测是否操作tg_file表
    const tgFileTableRegex = /(FROM|INTO|UPDATE|DELETE)\s+tg_file/i;
    if (tgFileTableRegex.test(sql)) {
      client = couchbaseClientFile;
    }
    // 执行查询
    const result = await client.query(sql, []);
    return result;
  } catch (error) {
    //console.error('智能查询失败:', error);
    throw error;
  }
}

async function squery1y(params: any): Promise<any> {
  const sql = params["sql"];
  const bin = params["bin"] || [];
  try {
    // 检测SQL语句中的表名，确定使用哪个Couchbase客户端
    let client = couchbaseClient; // 默认使用主客户端

    // 检查是否包含tg_file表，如果是则使用文件客户端
    // 使用正则表达式精确检测是否操作tg_file表
    const tgFileTableRegex = /(FROM|INTO|UPDATE|DELETE)\s+tg_file/i;
    if (tgFileTableRegex.test(sql)) {
      client = couchbaseClientFile;
    }
    // 执行查询
    const result = await client.query(sql, bin);
    return result;
  } catch (error) {
    //console.error('智能查询失败:', error);
    throw error;
  }
}







async function cacheobj(): Promise<any> {
  try {
    const sqls = [
      `SELECT blog_id, title,  time 
       FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_POSTS}\` 
       WHERE blog_id > 0 
       ORDER BY blog_id DESC LIMIT 5`,
      `SELECT category_id, category_name, catenum 
       FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_CATEGORY}\` 
       WHERE  catenum > 0 
       ORDER BY catenum DESC`,
      `SELECT id, name 
       FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_TAGS}\` 
       WHERE  cate_num > 0 
       ORDER BY cate_num DESC LIMIT 10`,

      // 查询归档月份和文章计数
      `SELECT year_month AS y, count 
       FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_ARCHIVE_MONTHS}\` 
       WHERE count > 0 
       ORDER BY year_month DESC`,


      `SELECT COUNT(*) AS postscount 
       FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_POSTS}\``,
      `SELECT COUNT(*) AS categorycount 
       FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_CATEGORY}\` 
       WHERE tagdel = 0`,
      `SELECT COUNT(*) AS tagscount 
       FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_TAGS}\` 
       WHERE state = 1`,
    ];

    const results = await couchbaseClient.query<any>(sqls);

    if (!Array.isArray(results) || results.length < 7) {
      return false;
    }

    const [blogPosts, categories, tags, archives, postCount, categoryCount, tagCount] = results;

    const archivesDoc = {
      id: "archives::1",
      newblog: JSON.stringify(blogPosts),
      categories: JSON.stringify(categories),
      tags: JSON.stringify(tags),
      archives: JSON.stringify(archives),
      postscount: JSON.stringify(postCount[0].postscount),
      tagscount: JSON.stringify(tagCount[0].tagscount),
      categorycount: JSON.stringify(categoryCount[0].categorycount),
    };

    await couchbaseClient.table(COLLECTIONS.BLOG_ARCHIVES).upsert("archives::1", archivesDoc);

    return { status: "success" };
  } catch (error) {
    //console.error("更新缓存失败:", error);
    return false;
  }
}

async function queryBlogPosts(): Promise<any> {
  try {
    const sqls = [
      `SELECT blog_posts.* FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_POSTS}\` LIMIT 2`,
      `SELECT blog_posts.* FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.BLOG_POSTS}\` LIMIT 1`,
    ];
    const results = await couchbaseClient.query<any>(sqls);
    return results;
  } catch (error) {
    //console.error("查询 blog_posts 失败:", error);
    throw error;
  }
}

// 添加图片记录
async function addTgFile(params: Partial<{
  id?: number;
  fullId: string;
  TgFileId: string;
  FileName: string;
  FileSize: string;
  TimeStamp: string;
  haxmd5: string | null;
  info_id?: number;
  postimagedown: string;
  catbox_moe: string;
  picb: string;
  imge: string | null;
  dataset_id?: number;
  relative_path?: string;
}>) {
  try {
    const id = params.id ?? (await getNextTgFileId());
    const uuid = generatecryptoUUIDv4();
    const key = `${uuid}`;
    const doc = {
      id,
      fullId: params.fullId ?? "",
      TgFileId: params.TgFileId ?? "",
      FileName: params.FileName ?? "",
      FileSize: params.FileSize ?? "0",
      TimeStamp: params.TimeStamp ?? new Date().toISOString().replace("T", " ").slice(0, 19),
      haxmd5: params.haxmd5 ?? null,
      info_id: params.info_id ?? 0,
      postimagedown: params.postimagedown ?? "",
      catbox_moe: params.catbox_moe ?? "",
      picb: params.picb ?? "",
      imge: params.imge ?? null,
      dataset_id: params.dataset_id ?? 0,
      relative_path: params.relative_path ?? ""
    };
    const result = await couchbaseClientFile.table(COLLECTIONS.TG_FILE).insert(key, doc);
    //console.log(result);
    return result// 返回数字ID
  } catch (error) {
    //console.error("添加图片记录失败:", error);
    throw error;
  }
}

// 删除图片记录（通过 fullId 逻辑删除）
async function deleteTgFile(fullId: string): Promise<boolean> {
  try {
    const result = await couchbaseClientFile.query(
      `UPDATE \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.TG_FILE}\` 
       SET del = 1 
       WHERE fullId = $1 
       RETURNING id`,
      [fullId]
    );
    return result.length > 0;
  } catch (error) {
    //console.error(`删除图片记录失败 (fullId: ${fullId}):`, error);
    throw error;
  }
}

// 局部更新图片记录（通过 fullId）
async function updateTgFile(fullId: string, updates: Partial<{
  id?: number;
  fullId: string;
  TgFileId: string;
  FileName: string;
  FileType: string;
  FileSize: string;
  ListType: string;
  TimeStamp: string;
  Channel: string;
  del?: number;
  haxmd5: string | null;
  info_id?: number;
  postimagedown: string;
  catbox_moe: string;
  picb: string;
  imge: string | null;
}>): Promise<boolean> {
  try {
    const setClauses = Object.entries(updates)
      .map(([key, value]) => `\`${key}\` = ${typeof value === "string" ? `"${value}"` : value}`)
      .join(", ");
    if (!setClauses) {
      throw new Error("No fields provided for update");
    }
    const result = await couchbaseClientFile.query(
      `UPDATE \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.TG_FILE}\` 
       SET ${setClauses} 
       WHERE fullId = $1 
       RETURNING id`,
      [fullId]
    );
    return result.length > 0;
  } catch (error) {
    //console.error(`更新图片记录失败 (fullId: ${fullId}):`, error);
    throw error;
  }
}

/**
 * 智能SQL查询函数
 * 自动检测SQL语句中的表名，选择合适的Couchbase客户端
 * 自动补全缺失的bucket和scope路径
 */
async function smartQuery(sql: string, params: any[] = []): Promise<any> {
  try {
    // 检测SQL语句中的表名，确定使用哪个Couchbase客户端
    let client = couchbaseClient; // 默认使用主客户端

    // 检查是否包含tg_file表，如果是则使用文件客户端
    // 使用正则表达式精确检测是否操作tg_file表
    const tgFileTableRegex = /(FROM|INTO|UPDATE|DELETE)\s+tg_file/i;
    if (tgFileTableRegex.test(sql)) {
      client = couchbaseClientFile;
    }
    // 自动补全缺失的bucket和scope路径
    const processedSql = autoCompleteSqlPath(sql, client);

    // 执行查询
    const result = await client.query(processedSql, params);
    return result;
  } catch (error) {
    //console.error('智能查询失败:', error);
    throw error;
  }
}

/**
 * 自动补全SQL语句中的bucket和scope路径
 */
/**
 * 自动补全SQL语句中的bucket和scope路径，并为字段名添加反引号
 */
/**
 * 自动补全SQL语句中的bucket和scope路径，并为字段名添加反引号
 */
/**
 * 自动补全SQL语句中的bucket和scope路径，并为字段名添加反引号
 * 支持处理多条SQL语句
 */
function autoCompleteSqlPath(sql: string, client: any): string {
  // 分割多条SQL语句（以分号分隔）
  const sqlStatements = sql.split(';')
    .map(statement => statement.trim())
    .filter(statement => statement.length > 0);

  // 处理每条SQL语句
  const processedStatements = sqlStatements.map(statement => {
    let processedSql = statement;

    // 正则表达式匹配表名（不包含路径的表名）
    const tableNameRegex = /(?:FROM|JOIN|UPDATE|INSERT\s+INTO|DELETE\s+FROM)\s+`?([a-zA-Z_][a-zA-Z0-9_]*)`?(?:\s|$|;|,)/gi;

    let match;

    // 查找所有需要补全的表名
    while ((match = tableNameRegex.exec(statement)) !== null) {
      const tableName = match[1];

      // 检查表名是否在COLLECTIONS中定义
      // 如果表名没有包含完整路径，则自动补全
      if (!statement.includes(`\`${client.bucket}\`.\`${client.scope}\`.\`${tableName}\``)) {
        const fullPath = `\`${client.bucket}\`.\`${client.scope}\`.\`${tableName}\``;
        //processedSql = processedSql.replace(new RegExp(`\\b${tableName}\\b`, 'g'), fullPath);
        const tableOnlyRegex = new RegExp(`((?:FROM|JOIN|UPDATE|INSERT\\s+INTO|DELETE\\s+FROM)\\s+)\\b${tableName}\\b(?!\\.)`, 'gi');
        processedSql = processedSql.replace(tableOnlyRegex, `$1${fullPath}`);
      }

    }

    // 为字段名添加反引号（处理SELECT语句中的字段）
    const selectFieldRegex = /SELECT\s+(.*?)\s+FROM/gi;
    let selectMatch;

    while ((selectMatch = selectFieldRegex.exec(processedSql)) !== null) {
      const fieldsPart = selectMatch[1];

      // 如果字段部分不包含反引号，则自动添加
      if (!fieldsPart.includes('`')) {
        // 同时支持中文逗号和英文逗号分割字段
        const fieldsWithBackticks = fieldsPart
          .split(/[,，]/) // 同时匹配英文逗号和中文逗号
          .map(field => field.trim())
          .filter(field => field.length > 0) // 过滤空字段
          .map(field => {
            // 跳过星号(*)和函数调用
            if (field === '*' || field.includes('(')) {
              return field;
            }
            // 为字段名添加反引号
            return `\`${field}\``;
          })
          .join(', '); // 统一使用英文逗号连接

        processedSql = processedSql.replace(fieldsPart, fieldsWithBackticks);
      }
    }

    return processedSql;
  });

  // 重新组合处理后的语句，添加分号分隔
  const finalSql = processedStatements.join('; ');
  //console.log("processedSql:", finalSql);
  return finalSql;
}
async function queryTgFile({
  where = {},
  fields = ["id", "fullId"],
  orderBy = "",
  desc = true,
  limit = 20
}) {
  try {
    // 构造 WHERE 子句
    const whereClauses = Object.entries(where)
      .map(([key, value]) => `${key} = ${typeof value === "string" ? `"${value}"` : value}`)
      .join(" AND ");

    // 构造字段列表
    const fieldList = fields.map(f => `\`${f}\``).join(", ");

    // 构造排序子句（可为空）
    const orderClause = orderBy ? `ORDER BY \`${orderBy}\` ${desc ? "DESC" : "ASC"}` : "";

    // 构造 LIMIT 子句
    const limitClause = limit > 0 ? `LIMIT ${limit}` : "";

    // 拼接完整查询
    const query = `
      SELECT ${fieldList}
      FROM \`${couchbaseClient.bucket}\`.\`${couchbaseClient.scope}\`.\`${COLLECTIONS.TG_FILE}\`
      ${whereClauses ? `WHERE ${whereClauses}` : ""}
      ${orderClause}
      ${limitClause}
    `;
    const result = await couchbaseClientFile.query(query);
    return result || [];
  } catch (error) {
    throw new Error(`查询失败: ${error}`);
  }
}