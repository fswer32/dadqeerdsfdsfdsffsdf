import * as couchbase from 'couchbase';

let cluster: couchbase.Cluster | null = null;
let bucket: couchbase.Bucket | null = null;
let collection: couchbase.Collection | null = null;

let clusterFile: couchbase.Cluster | null = null;
let bucketFile: couchbase.Bucket | null = null;
let collectionFile: couchbase.Collection | null = null;

const COLLECTIONS = {
  BLOG_POSTS: "blog_posts",
  BLOG_CATEGORY: "blog_category",
  BLOG_TAGS: "blog_tags",
  POST_CATE: "post_cate",
  POST_TAG: "post_tag",
  BLOG_ARCHIVES: "blog_archives",
  COUNTER: "counter",
  TG_FILE: "tg_file",
  BLOG_ARCHIVE_MONTHS: "blog_archive_months",
};

async function initConnection() {
  if (!cluster) {
    cluster = await couchbase.connect(process.env.COUCHBASE_MAIN_URL_NODE || "couchbase://localhost", {
      username: process.env.COUCHBASE_USERNAME || "Administrator",
      password: process.env.COUCHBASE_PASSWORD || "password",
    });
    bucket = cluster.bucket(process.env.COUCHBASE_BUCKET || "o");
    collection = bucket.defaultCollection();
  }
}

async function initConnectionFile() {
  if (!clusterFile) {
    clusterFile = await couchbase.connect(process.env.COUCHBASE_FILE_URL_NODE || "couchbase://localhost", {
      username: process.env.COUCHBASE_USERNAME || "Administrator",
      password: process.env.COUCHBASE_PASSWORD || "password",
    });
    bucketFile = clusterFile.bucket(process.env.COUCHBASE_BUCKET || "o");
    collectionFile = bucketFile.defaultCollection();
  }
}

function getCollection(collectionName: string, isFile = false): couchbase.Collection {
  if (isFile) {
    if (!bucketFile) throw new Error("File bucket not initialized");
    return bucketFile.scope(process.env.COUCHBASE_SCOPE || "db").collection(collectionName);
  }
  if (!bucket) throw new Error("Main bucket not initialized");
  return bucket.scope(process.env.COUCHBASE_SCOPE || "db").collection(collectionName);
}

async function intsrt(str: string): Promise<number> {
  const int = parseInt(str);
  const b = Math.pow(2, 31);
  if (isNaN(int)) return 0;
  if (int < -b) return -b;
  if (int > b - 1) return b - 1;
  return int;
}

async function getNextBlogId(): Promise<number> {
  await initConnection();
  try {
    const result = await cluster!.query<{ max_blog_id: number }>(
      `SELECT MAX(blog_id) as max_blog_id FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_POSTS}\``
    );
    return (result.rows[0]?.max_blog_id ?? 0) + 1;
  } catch {
    return 1;
  }
}

async function getNextCategoryId(): Promise<number> {
  await initConnection();
  const result = await cluster!.query<{ value: number }>(
    `UPDATE \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.COUNTER}\` 
     USE KEYS $counterKey 
     SET \`value\` = IFMISSINGORNULL(\`value\`, 0) + 1 
     RETURNING \`value\``,
    { parameters: { counterKey: "counter::category_id" } }
  );
  return result.rows[0]?.value ?? 1;
}

async function getNextTagId(): Promise<number> {
  await initConnection();
  const result = await cluster!.query<{ value: number }>(
    `UPDATE \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.COUNTER}\` 
     USE KEYS $counterKey 
     SET \`value\` = IFMISSINGORNULL(\`value\`, 0) + 1 
     RETURNING \`value\``,
    { parameters: { counterKey: "counter::tag_id" } }
  );
  return result.rows[0]?.value ?? 1;
}

async function getNextPostCateId(): Promise<number> {
  await initConnection();
  const result = await cluster!.query<{ value: number }>(
    `UPDATE \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.COUNTER}\` 
     USE KEYS $counterKey 
     SET \`value\` = IFMISSINGORNULL(\`value\`, 0) + 1 
     RETURNING \`value\``,
    { parameters: { counterKey: "counter::post_cate_id" } }
  );
  return result.rows[0]?.value ?? 1;
}

async function getNextPostTagId(): Promise<number> {
  await initConnection();
  const result = await cluster!.query<{ value: number }>(
    `UPDATE \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.COUNTER}\` 
     USE KEYS $counterKey 
     SET \`value\` = IFMISSINGORNULL(\`value\`, 0) + 1 
     RETURNING \`value\``,
    { parameters: { counterKey: "counter::post_tag_id" } }
  );
  return result.rows[0]?.value ?? 1;
}

async function getNextTgFileId(): Promise<number> {
  await initConnectionFile();
  const result = await clusterFile!.query<{ value: number }>(
    `UPDATE \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.COUNTER}\` 
     USE KEYS $counterKey 
     SET \`value\` = IFMISSINGORNULL(\`value\`, 0) + 1 
     RETURNING \`value\``,
    { parameters: { counterKey: "counter::tg_file_id" } }
  );
  if (!result.rows[0]?.value) throw new Error("Failed to increment tg_file_id");
  return result.rows[0].value;
}

async function processCategories(categories: string[], blogId: string): Promise<void> {
  await initConnection();
  const postCateCollection = getCollection(COLLECTIONS.POST_CATE);
  const blogCategoryCollection = getCollection(COLLECTIONS.BLOG_CATEGORY);

  for (const category of categories) {
    if (!category) continue;

    try {
      const getResult = await blogCategoryCollection.get(`category_name::${category}`);
      const existingCategory = getResult.content as { category_id: number; category_name: string; catenum: number };
      
      const categoryId = existingCategory.category_id;
      await blogCategoryCollection.replace(`category_id::${categoryId}`, {
        ...existingCategory,
        catenum: existingCategory.catenum + 1,
      });

      const postCateId = await getNextPostCateId();
      await postCateCollection.insert(`post_cate::${blogId}::${categoryId}`, {
        id: postCateId,
        blogid: parseInt(blogId),
        cateid: categoryId,
      });
    } catch {
      const categoryId = await getNextCategoryId();
      await blogCategoryCollection.insert(`category_id::${categoryId}`, {
        category_id: categoryId,
        category_name: category,
        catenum: 1,
        tagdel: 0,
      });

      const postCateId = await getNextPostCateId();
      await postCateCollection.insert(`post_cate::${blogId}::${categoryId}`, {
        id: postCateId,
        blogid: parseInt(blogId),
        cateid: categoryId,
      });
    }
  }

  const deleteResult = await cluster!.query(
    `DELETE FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.POST_CATE}\` 
     WHERE blogid = $blogId`,
    { parameters: { blogId: parseInt(blogId) } }
  );
}

async function processTags(tags: string[], blogId: string): Promise<void> {
  await initConnection();
  const postTagCollection = getCollection(COLLECTIONS.POST_TAG);
  const blogTagsCollection = getCollection(COLLECTIONS.BLOG_TAGS);

  for (const tag of tags) {
    if (!tag) continue;

    try {
      const getResult = await blogTagsCollection.get(`name::${tag}`);
      const existingTag = getResult.content as { id: number; name: string; cate_num: number };
      
      const tagId = existingTag.id;
      await blogTagsCollection.replace(`id::${tagId}`, {
        ...existingTag,
        cate_num: existingTag.cate_num + 1,
      });

      const postTagId = await getNextPostTagId();
      await postTagCollection.insert(`post_tag::${blogId}::${tagId}`, {
        id: postTagId,
        post_id: parseInt(blogId),
        tag: tagId,
      });
    } catch {
      const tagId = await getNextTagId();
      await blogTagsCollection.insert(`id::${tagId}`, {
        id: tagId,
        name: tag,
        cate_num: 1,
        state: 1,
      });

      const postTagId = await getNextPostTagId();
      await postTagCollection.insert(`post_tag::${blogId}::${tagId}`, {
        id: postTagId,
        post_id: parseInt(blogId),
        tag: tagId,
      });
    }
  }

  await cluster!.query(
    `DELETE FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.POST_TAG}\` 
     WHERE post_id = $postId`,
    { parameters: { postId: parseInt(blogId) } }
  );
}

async function saveAddNew(params: any): Promise<number> {
  await initConnection();
  try {
    const {
      blog_id: inputBlogId,
      title,
      description,
      content,
      time,
      last_update_time,
      cover_image_url,
      category: categoryRaw,
      tag: tagRaw,
      albumId = "",
      del = 0,
    } = params;

    let finalBlogId: number;
    if (inputBlogId && inputBlogId !== "" && !isNaN(Number(inputBlogId))) {
      finalBlogId = await intsrt(inputBlogId);
    } else {
      finalBlogId = await getNextBlogId();
    }

    const category1 = categoryRaw.toUpperCase().replace(/，/g, ",");
    const categories = category1.split(/[,，]+/).filter(Boolean);
    const tag1 = tagRaw.toUpperCase().replace(/，/g, ",");
    const tags = tag1.split(/[,，]+/).filter(Boolean);

    const blogPostsCollection = getCollection(COLLECTIONS.BLOG_POSTS);
    const blogDoc = {
      blog_id: finalBlogId,
      title,
      description,
      content,
      category: category1,
      tag: tag1,
      time,
      last_update_time,
      cover_image_url,
      del,
      album_id: albumId,
    };

    await blogPostsCollection.insert(`post::${finalBlogId}`, blogDoc);

    let yearMonth = '';
    if (params.time && typeof params.time === 'string' && params.time.match(/^\d{4}-\d{1,2}-\d{1,2}\s/)) {
      yearMonth = params.time.substring(0, 7);
      yearMonth = yearMonth.replace(/-(\d)$/, '-0$1');
    }

    if (yearMonth) {
      const blogArchiveMonthsCollection = getCollection(COLLECTIONS.BLOG_ARCHIVE_MONTHS);
      const monthDocId = `month::${yearMonth}`;
      try {
        const monthResult = await blogArchiveMonthsCollection.get(monthDocId);
        const monthDoc = monthResult.content as { count: number };
        await blogArchiveMonthsCollection.replace(monthDocId, {
          id: monthDocId,
          year_month: yearMonth,
          count: monthDoc.count + 1,
        });
      } catch {
        await blogArchiveMonthsCollection.insert(monthDocId, {
          id: monthDocId,
          year_month: yearMonth,
          count: 1,
        });
      }
    }

    await processCategories(categories, finalBlogId.toString());
    await processTags(tags, finalBlogId.toString());
    await cacheobj();
    return 1;
  } catch (error) {
    console.error("保存新文章失败:", error);
    throw error;
  }
}

async function saveEdit(params: any): Promise<number> {
  await initConnection();
  try {
    const {
      blog_id: blogIdStr,
      title,
      description,
      content,
      time,
      last_update_time,
      cover_image_url,
      category: categoryRaw,
      tag: tagRaw,
      albumId = "",
      del = 0,
    } = params;

    const category1 = categoryRaw.toUpperCase().replace(/，/g, ",");
    const categories = category1.split(/[,，]+/).filter(Boolean);
    const tag1 = tagRaw.toUpperCase().replace(/，/g, ",");
    const tags = tag1.split(/[,，]+/).filter(Boolean);

    const blog_id = await intsrt(blogIdStr);
    const blogPostsCollection = getCollection(COLLECTIONS.BLOG_POSTS);
    const blogKey = `post::${blog_id}`;

    const getResult = await blogPostsCollection.get(blogKey);
    const existingDoc = getResult.content;

    const blogDoc = {
      ...existingDoc,
      blog_id,
      title,
      description,
      content,
      category: category1,
      tag: tag1,
      time,
      last_update_time,
      cover_image_url,
      del,
      album_id: albumId,
    };

    await blogPostsCollection.replace(blogKey, blogDoc);

    await processCategories(categories, blog_id.toString());
    await processTags(tags, blog_id.toString());
    await cacheobj();

    return 1;
  } catch (error) {
    console.error("编辑文章失败:", error);
    throw error;
  }
}

export async function savesqlcubnode(params1: any): Promise<any> {
  let params: any;
  try {
    params = JSON.parse(params1);
  } catch (error) {
    console.error("JSON 解析失败:", error);
    return "infodata";
  }

  try {
    const type = params["type"];
    let reinfo: any = "infodata";

    switch (type) {
      case "query":
        reinfo = await squery(params["sql"]);
        break;
      case "query1":
        reinfo = await squery1(params);
        break;
      case "index":
        reinfo = await sindex(params);
        break;
      case "tags":
        reinfo = await stags(params);
        break;
      case "categories":
        reinfo = await scategories(params);
        break;
      case "archives":
        reinfo = await sarchives(params);
        break;
      case "tagspost":
        reinfo = await stagspost(params);
        break;
      case "posts":
        reinfo = await sposts(params);
        break;
      case "saveEdit":
        reinfo = await saveEdit(params);
        break;
      case "saveAddNew":
        reinfo = await saveAddNew(params);
        break;
      case "deleted":
        reinfo = await sdel(params);
        break;
      case "addTgFile":
        reinfo = await addTgFile(params);
        break;
      case "deleteTgFile":
        reinfo = await deleteTgFile(params.fullId);
        break;
      case "updateTgFile":
        reinfo = await updateTgFile(params.fullId, params.updates);
        break;
      case "queryTgFile":
        reinfo = await queryTgFile(params);
        break;
      default:
        reinfo = "infodata";
    }
    return reinfo;
  } catch (error) {
    console.error("savesql 执行失败:", error);
    throw error;
  }
}

async function runQuery(sql: string | string[], args: any[] = [], isFile = false): Promise<any> {
  await (isFile ? initConnectionFile() : initConnection());
  const targetCluster = isFile ? clusterFile! : cluster!;

  if (Array.isArray(sql)) {
    const results = await Promise.all(
      sql.map(statement => targetCluster.query(statement, { parameters: args }))
    );
    return results.map(r => r.rows);
  }

  const result = await targetCluster.query(sql, { parameters: args });
  return result.rows;
}

async function squery(sql: string): Promise<any> {
  try {
    return await runQuery(sql, []);
  } catch (error) {
    console.error("查询失败:", error);
    throw error;
  }
}

async function squery1(params: any): Promise<any> {
  const sql = params["sql"];
  const bin = params["bin"] || [];
  try {
    return await runQuery(sql, bin);
  } catch (error) {
    console.error("查询失败:", error);
    throw error;
  }
}

async function sposts(params: any): Promise<any> {
  let categories = "";
  if (params.hasOwnProperty("categories")) {
    categories = params["categories"];
  }
  if (!categories) return "infodata";

  const sqls = [
    `SELECT blog_id FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_POSTS}\` ORDER BY blog_id DESC LIMIT 1`,
    `SELECT blog_id, title, content, tag, category, time, last_update_time, album_id FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_POSTS}\` WHERE blog_id = $1`,
    `SELECT * FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_ARCHIVES}\` WHERE id = 'archives::1'`,
    `(SELECT 'previous' AS type, blog_id, title, description, cover_image_url FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_POSTS}\` WHERE blog_id < $1 ORDER BY blog_id DESC LIMIT 1) UNION (SELECT 'next' AS type, blog_id, title, description, cover_image_url FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_POSTS}\` WHERE blog_id > $1 ORDER BY blog_id ASC LIMIT 1)`,
  ];

  const infocount = await runQuery(sqls, [categories]);

  if (!Array.isArray(infocount) || infocount.length < 4) {
    return { allchae: "", allchaeCO: "", psotinfo: "", fno: "1", prevNext: [] };
  }

  return {
    allchae: infocount[2],
    allchaeCO: infocount[0][0]?.blog_id ?? "",
    psotinfo: infocount[1],
    fno: "0",
    prevNext: infocount[3],
  };
}

async function stagspost(params: any): Promise<any> {
  let page = params.hasOwnProperty("page") ? await intsrt(params["page"]) : 1;
  let size = params.hasOwnProperty("size") ? await intsrt(params["size"]) : 40;
  if (page < 2) page = 1;

  let categories = params.hasOwnProperty("categories") ? params["categories"] : "";
  if (!categories) return "infodata";

  const slimit = (page - 1) * size;
  const sqls = [
    `SELECT COUNT(*) AS cn FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_TAGS}\` AS bt JOIN \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.POST_TAG}\` AS pt ON bt.id = pt.tag JOIN \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_POSTS}\` AS bp ON pt.post_id = bp.blog_id WHERE bt.name = $1 AND bt.state = 1`,
    `SELECT bp.description, bp.cover_image_url, bp.blog_id, bp.title, bp.time FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_TAGS}\` AS bt JOIN \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.POST_TAG}\` AS pt ON bt.id = pt.tag JOIN \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_POSTS}\` AS bp ON pt.post_id = bp.blog_id WHERE bt.name = $1 AND bp.blog_id > 0 ORDER BY bp.blog_id DESC LIMIT $2 OFFSET $3`,
    `SELECT * FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_ARCHIVES}\` WHERE id = 'archives::1'`,
  ];

  const infocount = await runQuery(sqls, [categories, slimit, size]);
  if (!Array.isArray(infocount) || infocount.length < 3) return "infodata";

  return { allchaeCO: infocount[0], psotinfo: infocount[1], allchae: infocount[2] };
}

async function sarchives(params: any): Promise<any> {
  let page = params.hasOwnProperty("page") ? await intsrt(params["page"]) : 1;
  let size = params.hasOwnProperty("size") ? await intsrt(params["size"]) : 40;
  if (page < 2) page = 1;

  let categories = params.hasOwnProperty("categories") ? params["categories"] : "";
  if (!categories) return "infodata";

  const slimit = (page - 1) * size;
  const sqls = [
    `SELECT COUNT(*) AS cn FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_POSTS}\` WHERE time LIKE '$1%'`,
    `SELECT description, cover_image_url, blog_id, title, time FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_POSTS}\` WHERE time LIKE '$1%' AND blog_id > 0 ORDER BY blog_id DESC LIMIT $2 OFFSET $3`,
    `SELECT * FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_ARCHIVES}\` WHERE id = 'archives::1'`,
  ];

  const infocount = await runQuery(sqls, [categories, slimit, size]);
  if (!Array.isArray(infocount) || infocount.length < 3) return "infodata";

  return { allchaeCO: infocount[0], psotinfo: infocount[1], allchae: infocount[2] };
}

async function scategories(params: any): Promise<any> {
  let page = params.hasOwnProperty("page") ? await intsrt(params["page"]) : 1;
  let size = params.hasOwnProperty("size") ? await intsrt(params["size"]) : 40;
  if (page < 2) page = 1;

  let categories = params.hasOwnProperty("categories") ? params["categories"] : "";
  if (!categories) return "infodata";

  const slimit = (page - 1) * size;
  const sqls = [
    `SELECT COUNT(*) AS cn FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_CATEGORY}\` AS bc JOIN \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.POST_CATE}\` AS pc ON bc.category_id = pc.cateid JOIN \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_POSTS}\` AS bp ON pc.blogid = bp.blog_id WHERE bc.category_name = $1 AND bc.tagdel = 0`,
    `SELECT bp.description, bp.cover_image_url, bp.blog_id, bp.title, bp.time FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_CATEGORY}\` AS bc JOIN \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.POST_CATE}\` AS pc ON bc.category_id = pc.cateid JOIN \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_POSTS}\` AS bp ON pc.blogid = bp.blog_id WHERE bc.category_name = $1 AND bp.blog_id > 0 ORDER BY bp.blog_id DESC LIMIT $2 OFFSET $3`,
    `SELECT * FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_ARCHIVES}\` WHERE id = 'archives::1'`,
  ];

  const infocount = await runQuery(sqls, [categories, slimit, size]);
  if (!Array.isArray(infocount) || infocount.length < 3) return "infodata";

  return { allchaeCO: infocount[0], psotinfo: infocount[1], allchae: infocount[2] };
}

async function stags(params: any): Promise<any> {
  let page = params.hasOwnProperty("page") ? await intsrt(params["page"]) : 1;
  let size = params.hasOwnProperty("size") ? await intsrt(params["size"]) : 40;
  if (page < 2) page = 1;

  const slimit = (page - 1) * size;
  const sqls = [
    `SELECT COUNT(*) AS cn FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_TAGS}\` WHERE state = 1`,
    `SELECT name FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_TAGS}\` WHERE state = 1 AND cate_num >= 0 ORDER BY cate_num DESC LIMIT $1 OFFSET $2`,
    `SELECT * FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_ARCHIVES}\` WHERE id = 'archives::1'`,
  ];

  const infocount = await runQuery(sqls, [size, slimit]);
  if (!Array.isArray(infocount) || infocount.length < 3) return "infodata";

  return { allchaeCO: infocount[0], psotinfo: infocount[1], allchae: infocount[2] };
}

async function sindex(params: any): Promise<any> {
  let page = params.hasOwnProperty("page") ? await intsrt(params["page"]) : 1;
  let size = params.hasOwnProperty("size") ? await intsrt(params["size"]) : 40;
  if (page < 2) page = 1;

  const slimit = (page - 1) * size;
  const sqls = [
    `SELECT COUNT(blog_id) AS cn FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_POSTS}\``,
    `SELECT cover_image_url, blog_id, title, description, time FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_POSTS}\` WHERE blog_id > 0 ORDER BY blog_id DESC LIMIT $1 OFFSET $2`,
    `SELECT * FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_ARCHIVES}\` WHERE id = 'archives::1'`,
  ];

  const infocount = await runQuery(sqls, [size, slimit]);
  if (!Array.isArray(infocount) || infocount.length < 3) return "infodata";

  return { allchaeCO: infocount[0], psotinfo: infocount[1], allchae: infocount[2] };
}

async function sdel(params: any): Promise<any> {
  let page = params.hasOwnProperty("page") ? await intsrt(params["page"]) : 1;
  let size = params.hasOwnProperty("size") ? await intsrt(params["size"]) : 40;
  if (page < 2) page = 1;

  const slimit = (page - 1) * size;
  const sqls = [
    `SELECT COUNT(blog_id) AS cn FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_POSTS}\` WHERE del = 1`,
    `SELECT cover_image_url, blog_id, title, description, time FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_POSTS}\` WHERE del = 1 ORDER BY blog_id DESC LIMIT $1 OFFSET $2`,
    `SELECT * FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_ARCHIVES}\` WHERE id = 'archives::1'`,
  ];

  const infocount = await runQuery(sqls, [size, slimit]);
  if (!Array.isArray(infocount) || infocount.length < 3) return "infodata";

  return { allchaeCO: infocount[0], psotinfo: infocount[1], allchae: infocount[2] };
}

async function cacheobj(): Promise<any> {
  await initConnection();
  try {
    const sqls = [
      `SELECT blog_id, title, time FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_POSTS}\` WHERE blog_id > 0 ORDER BY blog_id DESC LIMIT 5`,
      `SELECT category_id, category_name, catenum FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_CATEGORY}\` WHERE catenum > 0 ORDER BY catenum DESC`,
      `SELECT id, name FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_TAGS}\` WHERE cate_num > 0 ORDER BY cate_num DESC LIMIT 10`,
      `SELECT year_month AS y, count FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_ARCHIVE_MONTHS}\` WHERE count > 0 ORDER BY year_month DESC`,
      `SELECT COUNT(*) AS postscount FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_POSTS}\``,
      `SELECT COUNT(*) AS categorycount FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_CATEGORY}\` WHERE tagdel = 0`,
      `SELECT COUNT(*) AS tagscount FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.BLOG_TAGS}\` WHERE state = 1`,
    ];

    const results = await runQuery(sqls);
    if (!Array.isArray(results) || results.length < 7) return false;

    const [blogPosts, categories, tags, archives, postCount, categoryCount, tagCount] = results;

    const blogArchivesCollection = getCollection(COLLECTIONS.BLOG_ARCHIVES);
    await blogArchivesCollection.upsert("archives::1", {
      id: "archives::1",
      newblog: JSON.stringify(blogPosts),
      categories: JSON.stringify(categories),
      tags: JSON.stringify(tags),
      archives: JSON.stringify(archives),
      postscount: JSON.stringify(postCount[0].postscount),
      tagscount: JSON.stringify(tagCount[0].tagscount),
      categorycount: JSON.stringify(categoryCount[0].categorycount),
    });

    return { status: "success" };
  } catch (error) {
    console.error("更新缓存失败:", error);
    return false;
  }
}

async function addTgFile(params: any) {
  await initConnectionFile();
  try {
    const id = params.id ?? (await getNextTgFileId());
    const key = `tg_file::${id}`;
    const doc = {
      id,
      fullId: params.fullId ?? "",
      TgFileId: params.TgFileId ?? "",
      FileName: params.FileName ?? "",
      FileSize: params.FileSize ?? "0",
      TimeStamp: params.TimeStamp ?? new Date().toISOString().replace("T", " ").slice(0, 19),
      haxmd5: params.haxmd5 ?? null,
      info_id: params.info_id ?? 0,
      postimagedown: params.postimagedown ?? "",
      catbox_moe: params.catbox_moe ?? "",
      picb: params.picb ?? "",
      imge: params.imge ?? null,
      dataset_id: params.dataset_id ?? 0,
      relative_path: params.relative_path ?? "",
    };

    const tgFileCollection = getCollection(COLLECTIONS.TG_FILE, true);
    await tgFileCollection.insert(key, doc);
    return id;
  } catch (error) {
    console.error("添加图片记录失败:", error);
    throw error;
  }
}

async function deleteTgFile(fullId: string): Promise<boolean> {
  await initConnectionFile();
  try {
    const result = await clusterFile!.query(
      `UPDATE \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.TG_FILE}\` SET del = 1 WHERE fullId = $fullId RETURNING id`,
      { parameters: { fullId } }
    );
    return result.rows.length > 0;
  } catch (error) {
    console.error(`删除图片记录失败 (fullId: ${fullId}):`, error);
    throw error;
  }
}

async function updateTgFile(fullId: string, updates: any): Promise<boolean> {
  await initConnectionFile();
  try {
    const setClauses = Object.entries(updates)
      .map(([key, value]) => `\`${key}\` = ${typeof value === "string" ? `"${value}"` : value}`)
      .join(", ");
    if (!setClauses) throw new Error("No fields provided for update");

    const result = await clusterFile!.query(
      `UPDATE \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.TG_FILE}\` SET ${setClauses} WHERE fullId = $fullId RETURNING id`,
      { parameters: { fullId } }
    );
    return result.rows.length > 0;
  } catch (error) {
    console.error(`更新图片记录失败 (fullId: ${fullId}):`, error);
    throw error;
  }
}

async function queryTgFile({ where = {}, fields = ["id", "fullId"], orderBy = "", desc = true, limit = 20 }) {
  await initConnectionFile();
  try {
    const whereClauses = Object.entries(where)
      .map(([key, value]) => `${key} = ${typeof value === "string" ? `"${value}"` : value}`)
      .join(" AND ");

    const fieldList = fields.map(f => `\`${f}\``).join(", ");
    const orderClause = orderBy ? `ORDER BY \`${orderBy}\` ${desc ? "DESC" : "ASC"}` : "";
    const limitClause = limit > 0 ? `LIMIT ${limit}` : "";

    const query = `SELECT ${fieldList} FROM \`${process.env.COUCHBASE_BUCKET || 'o'}\`.\`${process.env.COUCHBASE_SCOPE || 'db'}\`.\`${COLLECTIONS.TG_FILE}\` ${whereClauses ? `WHERE ${whereClauses}` : ""} ${orderClause} ${limitClause}`;
    
    const result = await clusterFile!.query(query);
    return result.rows || [];
  } catch (error) {
    throw new Error(`查询失败: ${error}`);
  }
}