
// Couchbase Capella 提供的 CA 证书，用于 HTTPS 请求验证
const capellaCert = `
-----BEGIN CERTIFICATE-----
MIIDFTCCAf2gAwIBAgIRANLVkgOvtaXiQJi0V6qeNtswDQYJKoZIhvcNAQELBQAw
JDESMBAGA1UECgwJQ291Y2hiYXNlMQ4wDAYDVQQLDAVDbG91ZDAeFw0xOTEyMDYy
MjEyNTlaFw0yOTEyMDYyMzEyNTlaMCQxEjAQBgNVBAoMCUNvdWNoYmFzZTEOMAwG
A1UECwwFQ2xvdWQwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCfvOIi
enG4Dp+hJu9asdxEMRmH70hDyMXv5ZjBhbo39a42QwR59y/rC/sahLLQuNwqif85
Fod1DkqgO6Ng3vecSAwyYVkj5NKdycQu5tzsZkghlpSDAyI0xlIPSQjoORA/pCOU
WOpymA9dOjC1bo6rDyw0yWP2nFAI/KA4Z806XeqLREuB7292UnSsgFs4/5lqeil6
rL3ooAw/i0uxr/TQSaxi1l8t4iMt4/gU+W52+8Yol0JbXBTFX6itg62ppb/Eugmn
mQRMgL67ccZs7cJ9/A0wlXencX2ohZQOR3mtknfol3FH4+glQFn27Q4xBCzVkY9j
KQ20T1LgmGSngBInAgMBAAGjQjBAMA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYE
FJQOBPvrkU2In1Sjoxt97Xy8+cKNMA4GA1UdDwEB/wQEAwIBhjANBgkqhkiG9w0B
AQsFAAOCAQEARgM6XwcXPLSpFdSf0w8PtpNGehmdWijPM3wHb7WZiS47iNen3oq8
m2mm6V3Z57wbboPpfI+VEzbhiDcFfVnK1CXMC0tkF3fnOG1BDDvwt4jU95vBiNjY
xdzlTP/Z+qr0cnVbGBSZ+fbXstSiRaaAVcqQyv3BRvBadKBkCyPwo+7svQnScQ5P
Js7HEHKVms5tZTgKIw1fbmgR2XHleah1AcANB+MAPBCcTgqurqr5G7W2aPSBLLGA
fRIiVzm7VFLc7kWbp7ENH39HVG6TZzKnfl9zJYeiklo5vQQhGSMhzBsO70z4RRzi
DPFAN/4qZAgD5q3AFNIq2WWADFQGSwVJhg==
-----END CERTIFICATE-----
`;



// Couchbase 查询服务封装类
export class CouchbaseClientAPI {
  private readonly endpoint: string; // 查询服务地址
  private readonly auth: string;     // Basic Auth 认证信息
  public readonly bucket: string;    // 桶名
  public readonly scope: string;     // 作用域名

  constructor(
    host: string,
    username: string,
    password: string,
    bucket: string,
    scope: string
  ) {
    this.endpoint = host; // Couchbase 查询服务端口
    this.auth = "Basic " + Buffer.from(`${username}:${password}`).toString("base64");
    this.bucket = bucket;
    this.scope = scope;
  }

  /**
   * 绑定集合名，返回包含常用操作的代理对象
   */
  table(collection: string) {
    return {
      insert: async <T>(key: string, doc: T) => this.insert(key, doc, collection),
      upsert: async <T>(key: string, doc: T) => this.upsert(key, doc, collection),
      replace: async <T>(key: string, doc: T) => this.replace(key, doc, collection),
      patch: async <T extends Record<string, unknown>>(key: string, updates: T) =>
        this.patch(key, updates, collection),
      remove: async (key: string) => this.remove(key, collection),
      get: async <T>(key: string) => this.get<T>(key, collection),
    };
  }

  /**
   * 执行 SQL++ 查询语句，支持参数化
   */
  private async runQuery<T>(statement: string, args: unknown[] = []): Promise<T[]> {
    try {
      const params = new URLSearchParams({
        statement,
        scan_consistency: "not_bounded", // 非强一致性，性能更优
      });

      if (args.length > 0) {
        params.set("args", JSON.stringify(args)); // 参数化传参
      }

      const res = await fetch(this.endpoint, {
        method: "POST",
        headers: {
          Authorization: this.auth,
          "Content-Type": "application/x-www-form-urlencoded; charset=utf-8",
          "Referer": "http://aasasaxx.sexy.xx.kg",
        },
        body: params
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(`查询失败: ${res.status} - ${JSON.stringify(error)}`);
      }

      const json: any = await res.json();
      return json.results ?? [];
    } catch (error) {
      if (error instanceof Error && error.name === 'AbortError') {
        throw new Error('查询超时，请检查网络连接或重试');
      }
      throw error;
    }
  }

  /**
   * 支持单条或多条 SQL++ 查询语句并发执行
   */
  async query<T>(sql: string, args?: unknown[]): Promise<T[]>;
  async query<T>(sql: string[], args?: unknown[]): Promise<T[][]>;
  async query<T>(sql: string | string[], args: unknown[] = []): Promise<T[] | T[][]> {
    if (Array.isArray(sql)) {
      const queryPromises = sql.map((statement) => this.runQuery<T>(statement, args));
      return await Promise.all(queryPromises);
    }
    return await this.runQuery<T>(sql, args);
  }

  /**
   * 插入文档（文档必须不存在）
   */
  async insert<T>(key: string, doc: T, collection: string): Promise<{ insertId: string }> {
    const sql = `
      INSERT INTO \`${this.bucket}\`.\`${this.scope}\`.\`${collection}\`
      (KEY, VALUE) VALUES ($1, $2)
      RETURNING META().id AS insertId
    `;
    try {
      const result = await this.runQuery<{ insertId: string }>(sql, [key, doc]);
      return result[0] ?? { insertId: key };
    } catch (error) {
      if (error instanceof Error && error.message.includes('already exists')) {
        throw new Error(`文档键 '${key}' 已存在于集合 '${collection}' 中`);
      }
      throw error;
    }



  }

  /**
   * 插入或更新文档（存在则覆盖）
   */
  async upsert<T>(key: string, doc: T, collection: string): Promise<{ insertId: string }> {
    const sql = `
      UPSERT INTO \`${this.bucket}\`.\`${this.scope}\`.\`${collection}\`
      (KEY, VALUE) VALUES ($1, $2)
      RETURNING META().id AS insertId
    `;
    const result = await this.runQuery<{ insertId: string }>(sql, [key, doc]);
    return result[0] ?? { insertId: key };
  }

  /**
   * 替换整个文档内容（整文档覆盖）
   */
  async replace<T>(key: string, doc: T, collection: string): Promise<{ changedRows: number }> {
    const sql = `
    UPDATE \`${this.bucket}\`.\`${this.scope}\`.\`${collection}\` AS doc
    USE KEYS $1
    SET doc = $2
    RETURNING 1 AS changedRows
  `;
    const result = await this.runQuery<{ changedRows: number }>(sql, [key, doc]);
    return result[0] ?? { changedRows: 0 };
  }


  /**
   * 局部字段更新（只更新指定字段）
   */
  async patch<T extends Record<string, unknown>>(key: string, updates: T, collection: string): Promise<void> {
    const setClause = Object.keys(updates)
      .map((field, i) => `\`${field}\` = $${i + 2}`)
      .join(", ");
    const sql = `
      UPDATE \`${this.bucket}\`.\`${this.scope}\`.\`${collection}\`
      USE KEYS $1 SET ${setClause}
    `;
    const args = [key, ...Object.values(updates)];
    await this.runQuery(sql, args);
  }

  /**
   * 删除文档
   */
  async remove(key: string, collection: string): Promise<void> {
    const sql = `
      DELETE FROM \`${this.bucket}\`.\`${this.scope}\`.\`${collection}\`
      USE KEYS $1
    `;
    await this.runQuery(sql, [key]);
  }

  /**
   * 获取文档内容
   */
  async get<T>(key: string, collection: string): Promise<T | null> {
    const sql = `
  SELECT RAW doc FROM \`${this.bucket}\`.\`${this.scope}\`.\`${collection}\` AS doc 
  USE KEYS $1
`;

    const result = await this.runQuery<T>(sql, [key]);
    return result[0] ?? null;
  }
}


/**
 * 
 * const client = new CouchbaseClientAPI(
  "your-capella-host",     // Capella 查询服务主机名
  "your-username",         // 用户名
  "your-password",         // 密码
  "your-bucket",           // 桶名
  "your-scope"             // 作用域名
);

// 绑定集合
const users = client.table("users");

// 插入新用户
await users.insert("user::001", {
  name: "海燚",
  email: "haiyi@example.com",
  active: true,
});

// 局部更新用户字段
await users.patch("user::001", {
  active: false,
  lastLogin: Date.now(),
});

// 获取用户信息
const user = await users.get("user::001");
console.log(user);

// 删除用户
await users.remove("user::001");

 */