import { randomUUID } from "crypto";

export function generateUUID(): string {
  // 生成符合RFC 4122标准的UUID v4
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}
export function generatecryptoUUIDv4(): string {
  return randomUUID()
}
// 或者使用更简洁的现代方法
export function generateUUIDv4(): string {
  return crypto.randomUUID ? crypto.randomUUID() : 
    'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
}
// 生成00-46范围内的随机数（包含00和46）
export function generateRandom00to46() {
  const randomNum = Math.floor(Math.random() * 47); // 0-46
  return randomNum.toString().padStart(2, '0'); // 格式化为两位数
}

