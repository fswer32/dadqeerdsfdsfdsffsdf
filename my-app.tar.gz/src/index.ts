import { serve } from '@hono/node-server'
import { Hono } from 'hono'
import { savesql } from './db/database.js'
import { compress } from 'hono/compress';
import { savesqlcub } from "./db/saveCloud.js";
import { createClient } from '@libsql/client'
import { savesqlcubnode } from "./db/CouchbaseNode.js"; 
const app = new Hono()

let db: any = null

app.use('*', async (c, next) => {
  const start = Date.now()
  await next()
  const ms = Date.now() - start
  c.header('X-Response-Time', `${ms}ms`)
})

const getDb = () => {
  if (!db) {
    const url = process.env.TURSO_DATABASE_URL?.trim()
    const authToken = process.env.TURSO_AUTH_TOKEN?.trim()
    
    if (!url) throw new Error('TURSO_DATABASE_URL is not defined')
    if (!authToken) throw new Error('TURSO_AUTH_TOKEN is not defined')
    
    db = createClient({ url, authToken })
  }
  return db
}
// 使用压缩中间件
app.use('*', compress({
  encoding: 'gzip', // 可选：'gzip', 'deflate', 'br'（Brotli）
  threshold: 1024  // 最小压缩阈值（字节），默认 1024
}));

app.get('/', (c) => {
  return c.text('H')
})

app.post('/Honosql/isuu', async c => {
    // 头部验证 - 使用 process.env
  const header1 = c.req.header('UV6KKhdsigun')
  const header2 = c.req.header('aubHV-jdycykjnfshj')
  
  if (header1 !== process.env.UV6KKhdsigun || header2 !== process.env.aubHV_jdycykjnfshj) {
    return c.json({ error: 'Unauthorized' }, 401)
  }

  let type = await c.req.text()

  let resp4 = await savesql(type)

  if (resp4 === 'infodata') {
    return c.json({ error: '' }, 500)
  }
  return c.json(resp4)
})

app.post('/Honosql/couchbase/*', async c => {
   // 头部验证 - 使用 process.env
  const header1 = c.req.header('UV6KKhdsigun')
  const header2 = c.req.header('aubHV-jdycykjnfshj')
  
  if (header1 !== process.env.UV6KKhdsigun || header2 !== process.env.aubHV_jdycykjnfshj) {
    return c.json({ error: 'Unauthorized' }, 401)
  }


  let type = await c.req.text()

  let resp4 = await savesqlcub(type)

  if (resp4 === 'infodata') {
    return c.json({ error: '' }, 500)
  }
  return c.json(resp4)
})
//node couchbase 操作
app.post('/Honosql/nodecouchbase/ddh*', async c => {
   // 头部验证 - 使用 process.env
  const header1 = c.req.header('UV6KKhdsigun')
  const header2 = c.req.header('aubHV-jdycykjnfshj')
  
  if (header1 !== process.env.UV6KKhdsigun || header2 !== process.env.aubHV_jdycykjnfshj) {
    return c.json({ error: 'Unauthorized' }, 401)
  }


  let type = await c.req.text()

  let resp4 = await savesqlcubnode(type)

  if (resp4 === 'infodata') {
    return c.json({ error: '' }, 500)
  }
  return c.json(resp4)
})
app.post('/api/lz9tjnlhza7jfltx0xnzzj88i3glhu7du1', async (c) => {
  // 头部验证 - 使用 process.env
  const header1 = c.req.header('UV6KKhdsigun')
  const header2 = c.req.header('aubHV-jdycykjnfshj')
  
  if (header1 !== process.env.UV6KKhdsigun || header2 !== process.env.aubHV_jdycykjnfshj) {
    return c.json({ error: 'Unauthorized' }, 401)
  }

  const client = getDb()

  try {
    const params = await c.req.json()
    const { type, sql, bin } = params

    if (!sql) {
      return c.json({ error: 'Missing sql' }, 400)
    }

    let reinfo: any = 'infodata'

    if (type === 'query') {
      reinfo = await client.execute(sql)
    } else if (type === 'query1') {
      reinfo = await client.execute({ sql, args: bin ? [bin] : [] })
    } else {
      return c.json({ error: 'Invalid type' }, 400)
    }

    return c.json(reinfo)
  } catch (e: any) {
    return c.json({ error: e.message }, 500)
  }
})

app.onError((err, c) => {
  console.error(err)
  return c.json({ error: '' }, 500)
})

serve({
  fetch: app.fetch,
  port: 3000
}, (info) => {
  console.log(`Server is running on http://localhost:${info.port}`)
})